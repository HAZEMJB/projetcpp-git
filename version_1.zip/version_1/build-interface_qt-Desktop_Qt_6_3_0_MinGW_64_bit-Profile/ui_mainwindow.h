/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *icon_only_widget;
    QVBoxLayout *verticalLayout_14;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_13;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer_10;
    QPushButton *p20;
    QSpacerItem *verticalSpacer_5;
    QPushButton *p21;
    QSpacerItem *verticalSpacer_6;
    QPushButton *p22;
    QSpacerItem *verticalSpacer_7;
    QPushButton *p23;
    QSpacerItem *verticalSpacer_8;
    QPushButton *p24;
    QSpacerItem *verticalSpacer_9;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QWidget *icon_names_text_widget;
    QFrame *frame_3;
    QPushButton *p9;
    QFrame *frame;
    QHBoxLayout *horizontalLayout;
    QPushButton *p17;
    QLabel *label_3;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_12;
    QPushButton *p15;
    QPushButton *p16;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_9;
    QFrame *RH;
    QVBoxLayout *verticalLayout_5;
    QPushButton *p14;
    QFrame *frame_rh;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QFrame *SL;
    QVBoxLayout *verticalLayout_6;
    QPushButton *p11;
    QFrame *frame_sales;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_14;
    QFrame *frame_9;
    QVBoxLayout *verticalLayout_10;
    QPushButton *pushButton_6;
    QFrame *frame_ord_2;
    QVBoxLayout *verticalLayout_11;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QFrame *SK;
    QVBoxLayout *verticalLayout_7;
    QPushButton *p13;
    QFrame *frame_stc;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QPushButton *pushButton_25;
    QFrame *frame_8;
    QVBoxLayout *verticalLayout_8;
    QPushButton *p10;
    QFrame *frame_ord;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButton_26;
    QPushButton *pushButton_27;
    QPushButton *pushButton_28;
    QWidget *main_screen_widget;
    QWidget *heade_widget;
    QLineEdit *lineEdit;
    QPushButton *pushButton_13;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1264, 782);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color:rgb(245,250,254);\n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("#main_window_widget{\n"
"	background-color:rgb(131,255,189);\n"
"}\n"
"QPushButton#pushButton, #pushButton_6{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:hover, #pushButton_6:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed, #pushButton_6:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton, #p9 ,#p10 ,#p11 ,#p13 ,#p14{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButto"
                        "n:hover, #p9:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p9 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover, #p11:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p11 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover, #p10:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p10 :pressed{\n"
"	padding-left:5px;"
                        "\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#p14:hover, #p13:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p14:pressed,  #p13 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton #p14 ,#p15 ,#p16 ,#p17{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#p14:hover, #p15:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p14:pressed,  #p15 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	ba"
                        "ckground-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"QPushButton#p16:hover, #p17:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p16:pressed,  #p17 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#p20, #p21 ,#p22 ,#p23 ,#p24{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#p20:hover, #p21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p20:pressed,  #p21 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, "
                        "123, 111, 255);\n"
"}\n"
"\n"
"QPushButton#p22:hover, #p23:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p22:pressed,  #p23 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"\n"
"\n"
"}\n"
"\n"
"QPushButton#p24:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p24 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}"));
        icon_only_widget = new QWidget(centralwidget);
        icon_only_widget->setObjectName(QString::fromUtf8("icon_only_widget"));
        icon_only_widget->setGeometry(QRect(10, 20, 91, 721));
        icon_only_widget->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_14 = new QVBoxLayout(icon_only_widget);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        frame_2 = new QFrame(icon_only_widget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(frame_2);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        pushButton = new QPushButton(frame_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(16777215, 16777213));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../ressource/home.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon);

        verticalLayout_13->addWidget(pushButton);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_10);

        p20 = new QPushButton(frame_2);
        p20->setObjectName(QString::fromUtf8("p20"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../ressource/slack.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p20->setIcon(icon1);
        p20->setCheckable(true);
        p20->setAutoExclusive(true);

        verticalLayout_13->addWidget(p20);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_5);

        p21 = new QPushButton(frame_2);
        p21->setObjectName(QString::fromUtf8("p21"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../ressource/shopping-bag.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p21->setIcon(icon2);
        p21->setCheckable(true);
        p21->setAutoExclusive(true);

        verticalLayout_13->addWidget(p21);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_6);

        p22 = new QPushButton(frame_2);
        p22->setObjectName(QString::fromUtf8("p22"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("../ressource/heart.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p22->setIcon(icon3);
        p22->setCheckable(true);
        p22->setAutoExclusive(true);

        verticalLayout_13->addWidget(p22);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_7);

        p23 = new QPushButton(frame_2);
        p23->setObjectName(QString::fromUtf8("p23"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("../ressource/mail.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p23->setIcon(icon4);
        p23->setIconSize(QSize(50, 20));
        p23->setCheckable(true);
        p23->setAutoExclusive(true);

        verticalLayout_13->addWidget(p23);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_8);

        p24 = new QPushButton(frame_2);
        p24->setObjectName(QString::fromUtf8("p24"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("../ressource/layers.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p24->setIcon(icon5);
        p24->setIconSize(QSize(50, 20));
        p24->setCheckable(true);
        p24->setAutoExclusive(true);

        verticalLayout_13->addWidget(p24);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_9);


        verticalLayout_14->addWidget(frame_2);

        pushButton_15 = new QPushButton(icon_only_widget);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("../ressource/settings.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_15->setIcon(icon6);

        verticalLayout_14->addWidget(pushButton_15);

        pushButton_16 = new QPushButton(icon_only_widget);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/img/img/log-out.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_16->setIcon(icon7);

        verticalLayout_14->addWidget(pushButton_16);

        icon_names_text_widget = new QWidget(centralwidget);
        icon_names_text_widget->setObjectName(QString::fromUtf8("icon_names_text_widget"));
        icon_names_text_widget->setGeometry(QRect(110, 20, 191, 721));
        frame_3 = new QFrame(icon_names_text_widget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(10, 0, 151, 61));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        p9 = new QPushButton(frame_3);
        p9->setObjectName(QString::fromUtf8("p9"));
        p9->setGeometry(QRect(12, 39, 101, 20));
        p9->setMaximumSize(QSize(16777215, 16777213));
        p9->setIcon(icon);
        frame = new QFrame(frame_3);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(12, 12, 127, 20));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        horizontalLayout = new QHBoxLayout(frame);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        p17 = new QPushButton(frame);
        p17->setObjectName(QString::fromUtf8("p17"));
        p17->setMaximumSize(QSize(16777215, 16777213));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("../ressource/align-justify.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p17->setIcon(icon8);

        horizontalLayout->addWidget(p17);

        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout->addWidget(label_3);

        layoutWidget = new QWidget(icon_names_text_widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 650, 101, 49));
        verticalLayout_12 = new QVBoxLayout(layoutWidget);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        p15 = new QPushButton(layoutWidget);
        p15->setObjectName(QString::fromUtf8("p15"));
        p15->setIcon(icon6);

        verticalLayout_12->addWidget(p15);

        p16 = new QPushButton(layoutWidget);
        p16->setObjectName(QString::fromUtf8("p16"));
        p16->setIcon(icon7);

        verticalLayout_12->addWidget(p16);

        layoutWidget1 = new QWidget(icon_names_text_widget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 80, 151, 521));
        verticalLayout_9 = new QVBoxLayout(layoutWidget1);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        RH = new QFrame(layoutWidget1);
        RH->setObjectName(QString::fromUtf8("RH"));
        RH->setFrameShape(QFrame::StyledPanel);
        RH->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(RH);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        p14 = new QPushButton(RH);
        p14->setObjectName(QString::fromUtf8("p14"));
        p14->setIcon(icon1);
        p14->setCheckable(true);

        verticalLayout_5->addWidget(p14);

        frame_rh = new QFrame(RH);
        frame_rh->setObjectName(QString::fromUtf8("frame_rh"));
        frame_rh->setFrameShape(QFrame::StyledPanel);
        frame_rh->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame_rh);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton_8 = new QPushButton(frame_rh);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setCheckable(true);

        verticalLayout->addWidget(pushButton_8);

        pushButton_9 = new QPushButton(frame_rh);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setCheckable(true);

        verticalLayout->addWidget(pushButton_9);

        pushButton_10 = new QPushButton(frame_rh);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setCheckable(true);

        verticalLayout->addWidget(pushButton_10);


        verticalLayout_5->addWidget(frame_rh);


        verticalLayout_9->addWidget(RH);

        SL = new QFrame(layoutWidget1);
        SL->setObjectName(QString::fromUtf8("SL"));
        SL->setFrameShape(QFrame::StyledPanel);
        SL->setFrameShadow(QFrame::Raised);
        verticalLayout_6 = new QVBoxLayout(SL);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        p11 = new QPushButton(SL);
        p11->setObjectName(QString::fromUtf8("p11"));
        p11->setIcon(icon2);
        p11->setCheckable(true);

        verticalLayout_6->addWidget(p11);

        frame_sales = new QFrame(SL);
        frame_sales->setObjectName(QString::fromUtf8("frame_sales"));
        frame_sales->setFrameShape(QFrame::StyledPanel);
        frame_sales->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(frame_sales);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        pushButton_11 = new QPushButton(frame_sales);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_11);

        pushButton_12 = new QPushButton(frame_sales);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_12);

        pushButton_14 = new QPushButton(frame_sales);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_14);


        verticalLayout_6->addWidget(frame_sales);


        verticalLayout_9->addWidget(SL);

        frame_9 = new QFrame(layoutWidget1);
        frame_9->setObjectName(QString::fromUtf8("frame_9"));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        verticalLayout_10 = new QVBoxLayout(frame_9);
        verticalLayout_10->setSpacing(0);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        pushButton_6 = new QPushButton(frame_9);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setIcon(icon3);
        pushButton_6->setCheckable(true);

        verticalLayout_10->addWidget(pushButton_6);

        frame_ord_2 = new QFrame(frame_9);
        frame_ord_2->setObjectName(QString::fromUtf8("frame_ord_2"));
        frame_ord_2->setFrameShape(QFrame::StyledPanel);
        frame_ord_2->setFrameShadow(QFrame::Raised);
        verticalLayout_11 = new QVBoxLayout(frame_ord_2);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        pushButton_35 = new QPushButton(frame_ord_2);
        pushButton_35->setObjectName(QString::fromUtf8("pushButton_35"));
        pushButton_35->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_35);

        pushButton_36 = new QPushButton(frame_ord_2);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_36);

        pushButton_37 = new QPushButton(frame_ord_2);
        pushButton_37->setObjectName(QString::fromUtf8("pushButton_37"));
        pushButton_37->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_37);


        verticalLayout_10->addWidget(frame_ord_2);


        verticalLayout_9->addWidget(frame_9);

        SK = new QFrame(layoutWidget1);
        SK->setObjectName(QString::fromUtf8("SK"));
        SK->setFrameShape(QFrame::StyledPanel);
        SK->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(SK);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        p13 = new QPushButton(SK);
        p13->setObjectName(QString::fromUtf8("p13"));
        p13->setIcon(icon4);
        p13->setIconSize(QSize(50, 20));
        p13->setCheckable(true);

        verticalLayout_7->addWidget(p13);

        frame_stc = new QFrame(SK);
        frame_stc->setObjectName(QString::fromUtf8("frame_stc"));
        frame_stc->setFrameShape(QFrame::StyledPanel);
        frame_stc->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_stc);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        pushButton_23 = new QPushButton(frame_stc);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_23);

        pushButton_24 = new QPushButton(frame_stc);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_24);

        pushButton_25 = new QPushButton(frame_stc);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_25);


        verticalLayout_7->addWidget(frame_stc);


        verticalLayout_9->addWidget(SK);

        frame_8 = new QFrame(layoutWidget1);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        verticalLayout_8 = new QVBoxLayout(frame_8);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        p10 = new QPushButton(frame_8);
        p10->setObjectName(QString::fromUtf8("p10"));
        p10->setIcon(icon5);
        p10->setCheckable(true);

        verticalLayout_8->addWidget(p10);

        frame_ord = new QFrame(frame_8);
        frame_ord->setObjectName(QString::fromUtf8("frame_ord"));
        frame_ord->setFrameShape(QFrame::StyledPanel);
        frame_ord->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(frame_ord);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        pushButton_26 = new QPushButton(frame_ord);
        pushButton_26->setObjectName(QString::fromUtf8("pushButton_26"));
        pushButton_26->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_26);

        pushButton_27 = new QPushButton(frame_ord);
        pushButton_27->setObjectName(QString::fromUtf8("pushButton_27"));
        pushButton_27->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_27);

        pushButton_28 = new QPushButton(frame_ord);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_28);


        verticalLayout_8->addWidget(frame_ord);


        verticalLayout_9->addWidget(frame_8);

        main_screen_widget = new QWidget(centralwidget);
        main_screen_widget->setObjectName(QString::fromUtf8("main_screen_widget"));
        main_screen_widget->setGeometry(QRect(310, 120, 911, 611));
        main_screen_widget->setStyleSheet(QString::fromUtf8("background-color:rgb(147, 237, 255)"));
        heade_widget = new QWidget(centralwidget);
        heade_widget->setObjectName(QString::fromUtf8("heade_widget"));
        heade_widget->setGeometry(QRect(310, 10, 911, 101));
        lineEdit = new QLineEdit(heade_widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(130, 30, 251, 28));
        pushButton_13 = new QPushButton(heade_widget);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(20, 30, 83, 29));
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(p14, &QPushButton::toggled, frame_rh, &QFrame::setHidden);
        QObject::connect(p11, &QPushButton::toggled, frame_sales, &QFrame::setHidden);
        QObject::connect(pushButton_6, &QPushButton::toggled, frame_ord_2, &QFrame::setHidden);
        QObject::connect(p13, &QPushButton::toggled, frame_stc, &QFrame::setHidden);
        QObject::connect(p10, &QPushButton::toggled, frame_ord, &QFrame::setHidden);
        QObject::connect(p9, &QPushButton::toggled, pushButton, &QPushButton::setChecked);
        QObject::connect(p14, &QPushButton::toggled, p20, &QPushButton::setChecked);
        QObject::connect(p11, &QPushButton::toggled, p21, &QPushButton::setChecked);
        QObject::connect(pushButton_6, &QPushButton::toggled, p22, &QPushButton::setChecked);
        QObject::connect(p13, &QPushButton::toggled, p23, &QPushButton::setChecked);
        QObject::connect(p10, &QPushButton::toggled, p24, &QPushButton::setChecked);
        QObject::connect(p15, &QPushButton::toggled, pushButton_15, &QPushButton::setChecked);
        QObject::connect(p16, &QPushButton::toggled, pushButton_16, &QPushButton::setChecked);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QString());
        p20->setText(QString());
        p21->setText(QString());
        p22->setText(QString());
        p23->setText(QString());
        p24->setText(QString());
        pushButton_15->setText(QString());
        pushButton_16->setText(QString());
        p9->setText(QCoreApplication::translate("MainWindow", "home    ", nullptr));
        p17->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "DashBoard", nullptr));
        p15->setText(QCoreApplication::translate("MainWindow", " Settings", nullptr));
        p16->setText(QCoreApplication::translate("MainWindow", "Log out", nullptr));
        p14->setText(QCoreApplication::translate("MainWindow", "HR manager", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p11->setText(QCoreApplication::translate("MainWindow", "Sales management", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Order Manager", nullptr));
        pushButton_35->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_36->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_37->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p13->setText(QCoreApplication::translate("MainWindow", "order management", nullptr));
        pushButton_23->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_24->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_25->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p10->setText(QCoreApplication::translate("MainWindow", "Stock management", nullptr));
        pushButton_26->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_27->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        pushButton_13->setText(QCoreApplication::translate("MainWindow", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
