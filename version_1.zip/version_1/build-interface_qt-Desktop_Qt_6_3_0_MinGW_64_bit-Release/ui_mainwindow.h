/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_15;
    QWidget *heade_widget;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *p17;
    QLabel *label;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QLineEdit *edit;
    QLabel *label_4;
    QWidget *main_screen_widget;
    QHBoxLayout *horizontalLayout_3;
    QStackedWidget *stackedWidget;
    QWidget *a1;
    QLineEdit *edit_2;
    QTableWidget *tableWidget;
    QFrame *frame_3;
    QFrame *frame;
    QDateEdit *dateEdit;
    QRadioButton *radioButton;
    QRadioButton *radioButton_3;
    QComboBox *comboBox;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_3;
    QLineEdit *lineEdit_16;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QDateEdit *dateEdit_2;
    QLabel *label_44;
    QLabel *label_45;
    QLabel *label_46;
    QPushButton *pushButton_20;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_39;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_40;
    QLabel *label_14;
    QLabel *label_15;
    QPushButton *pushButton_4;
    QLabel *label_28;
    QLabel *pic1;
    QLabel *label_42;
    QLineEdit *edit_5;
    QPushButton *pushButton_21;
    QPushButton *pushButton_29;
    QLabel *label_66;
    QComboBox *comboBox_3;
    QWidget *a4;
    QWidget *a5;
    QWidget *a3;
    QWidget *a2;
    QFrame *frame_11;
    QFrame *frame_12;
    QDateEdit *dateEdit_9;
    QRadioButton *radioButton_9;
    QRadioButton *radioButton_10;
    QComboBox *comboBox_7;
    QLineEdit *lineEdit_51;
    QPushButton *pushButton_30;
    QPushButton *pushButton_31;
    QLabel *label_67;
    QLineEdit *lineEdit_52;
    QLineEdit *lineEdit_53;
    QLineEdit *lineEdit_54;
    QLineEdit *lineEdit_55;
    QLineEdit *lineEdit_56;
    QLineEdit *lineEdit_57;
    QLineEdit *lineEdit_58;
    QLineEdit *lineEdit_59;
    QLabel *label_68;
    QLabel *label_69;
    QLabel *label_70;
    QLabel *label_71;
    QLabel *label_72;
    QLabel *label_73;
    QLabel *label_74;
    QLabel *label_75;
    QLabel *label_76;
    QDateEdit *dateEdit_10;
    QLabel *label_77;
    QLabel *label_78;
    QLabel *label_79;
    QPushButton *pushButton_32;
    QLabel *label_80;
    QWidget *icon_only_widget;
    QVBoxLayout *verticalLayout_14;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_13;
    QPushButton *pushButton;
    QPushButton *p20;
    QPushButton *p21;
    QPushButton *p22;
    QPushButton *p23;
    QPushButton *p24;
    QSpacerItem *verticalSpacer_9;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QWidget *icon_names_text_widget;
    QVBoxLayout *verticalLayout_16;
    QPushButton *p9;
    QVBoxLayout *verticalLayout_9;
    QFrame *RH;
    QVBoxLayout *verticalLayout_5;
    QPushButton *p14;
    QFrame *frame_rh;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QFrame *SL;
    QVBoxLayout *verticalLayout_6;
    QPushButton *p11;
    QFrame *frame_sales;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_14;
    QFrame *frame_9;
    QVBoxLayout *verticalLayout_10;
    QPushButton *pushButton_6;
    QFrame *frame_ord_2;
    QVBoxLayout *verticalLayout_11;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QFrame *SK;
    QVBoxLayout *verticalLayout_7;
    QPushButton *p13;
    QFrame *frame_stc;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QPushButton *pushButton_25;
    QFrame *frame_8;
    QVBoxLayout *verticalLayout_8;
    QPushButton *p10;
    QFrame *frame_ord;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButton_26;
    QPushButton *pushButton_27;
    QPushButton *pushButton_28;
    QVBoxLayout *verticalLayout_12;
    QSpacerItem *verticalSpacer;
    QPushButton *p15;
    QPushButton *p16;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1634, 1190);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color:rgb(245,250,254);\n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("#edit{\n"
"	padding-left:20px;\n"
"	border:1px solid gray;	\n"
"	border-raduis:10px;\n"
"\n"
"}\n"
"#frame{\n"
"padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"#main_window_widget{\n"
"	background-color:rgb(131,255,189);\n"
"}\n"
"QPushButton#pushButton, #pushButton_6{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:hover, #pushButton_6:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed, #pushButton_6:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton, #p9 ,#p10 ,#p11 ,#p13 ,#p14{\n"
"	background-color: q"
                        "lineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:hover, #p9:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p9 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover, #p11:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p11 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover, #p10:hover{\n"
"	backgro"
                        "und-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p10 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#p14:hover, #p13:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p14:pressed,  #p13 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton #p14 ,#p15 ,#p16 ,#p17{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#p14:hover, #p15:hover{\n"
"	background-color: qlineargradi"
                        "ent(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p14:pressed,  #p15 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"QPushButton#p16:hover, #p17:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p16:pressed,  #p17 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#p20, #p21 ,#p22 ,#p23 ,#p24{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#p20:hover, #p21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:"
                        "0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p20:pressed,  #p21 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"QPushButton#p22:hover, #p23:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p22:pressed,  #p23 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"\n"
"\n"
"}\n"
"\n"
"QPushButton#p24:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p24 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"/* Window "
                        "Background (main background) */\n"
"QWidget {\n"
"    background-color: qlineargradient(\n"
"        spread:pad, x1:0, y1:0, x2:1, y2:1, \n"
"        stop:0 rgba(30, 30, 60, 255), /* Dark blue at the top-left */\n"
"        stop:1 rgba(60, 90, 150, 255) /* Soft blue at the bottom-right */\n"
"    );\n"
"    color: #ffffff; /* White text color for contrast */\n"
"}\n"
"\n"
"/* Table Background (a bit transparent to show gradient) */\n"
"QTableWidget {\n"
"    background-color: rgba(255, 255, 255, 180); /* Slight transparency for table */\n"
"    alternate-background-color: rgba(255, 255, 255, 200); /* Transparent alternate rows */\n"
"    gridline-color: rgba(200, 200, 255, 180); /* Light gridlines */\n"
"    border: 1px solid rgba(255, 255, 255, 50); /* Subtle border */\n"
"}\n"
"\n"
"/* Header Background with a subtle glow effect */\n"
"QHeaderView::section {\n"
"    background-color: rgba(40, 60, 100, 255); /* Deep blue for headers */\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
""
                        "    border: 1px solid rgba(255, 255, 255, 60); /* Softer border */\n"
"}\n"
"\n"
"/* Buttons with a modern gradient and hover effect */\n"
"QPushButton {\n"
"    background-color: qlineargradient(\n"
"        spread:pad, x1:0, y1:0.5, x2:1, y2:0.5, \n"
"        stop:0 rgba(100, 120, 240, 255), \n"
"        stop:1 rgba(80, 100, 210, 255)\n"
"    );\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        spread:pad, x1:0, y1:0.5, x2:1, y2:0.5, \n"
"        stop:0 rgba(120, 150, 255, 255), \n"
"        stop:1 rgba(90, 130, 250, 255)\n"
"    );\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgba(80, 90, 180, 255); /* Darker blue when pressed */\n"
"}\n"
"\n"
"/* Scrollbar Customization */\n"
"QScrollBar:vertical {\n"
"    background: rgba(50, 50, 90, 255);\n"
"    border: none;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"    background: rgba(90, 110, 180, 255);\n"
"    min-height: 20px;\n"
""
                        "    border-radius: 5px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical:hover {\n"
"    background: rgba(120, 140, 200, 255);\n"
"}\n"
""));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(60, 0, 1461, 1176));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        heade_widget = new QWidget(layoutWidget);
        heade_widget->setObjectName(QString::fromUtf8("heade_widget"));
        horizontalLayout_4 = new QHBoxLayout(heade_widget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        p17 = new QPushButton(heade_widget);
        p17->setObjectName(QString::fromUtf8("p17"));
        p17->setMaximumSize(QSize(16777215, 16777213));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../ressource/align-justify.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p17->setIcon(icon);
        p17->setCheckable(true);

        horizontalLayout_2->addWidget(p17);

        label = new QLabel(heade_widget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        label_2 = new QLabel(heade_widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font1;
        font1.setBold(true);
        label_2->setFont(font1);

        horizontalLayout_2->addWidget(label_2);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        edit = new QLineEdit(heade_widget);
        edit->setObjectName(QString::fromUtf8("edit"));
        edit->setMinimumSize(QSize(0, 31));
        edit->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"\n"
"}"));

        horizontalLayout->addWidget(edit);

        label_4 = new QLabel(heade_widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(40, 40));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/img/img/user.svg")));

        horizontalLayout->addWidget(label_4);


        horizontalLayout_4->addLayout(horizontalLayout);


        verticalLayout_15->addWidget(heade_widget);

        main_screen_widget = new QWidget(layoutWidget);
        main_screen_widget->setObjectName(QString::fromUtf8("main_screen_widget"));
        main_screen_widget->setMaximumSize(QSize(16777215, 16777215));
        main_screen_widget->setStyleSheet(QString::fromUtf8("background-color:rgb(147, 237, 255)"));
        horizontalLayout_3 = new QHBoxLayout(main_screen_widget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        stackedWidget = new QStackedWidget(main_screen_widget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setStyleSheet(QString::fromUtf8("/* General Table Appearance */\n"
"QTableWidget {\n"
"    background-color: #e7f7f7; /* Light background for the table */\n"
"    alternate-background-color: #f0ffff; /* Lighter color for alternate rows */\n"
"    gridline-color: #d0e7e7; /* Soft gridline color */\n"
"    border: 2px solid #b0c4de; /* Border around the table */\n"
"    border-radius: 5px;\n"
"    font-size: 14px;\n"
"    color: #555; /* Text color */\n"
"    selection-background-color: #87cefa; /* Background color when a row is selected */\n"
"    selection-color: white; /* Text color when selected */\n"
"}\n"
"\n"
"/* Table Header */\n"
"QHeaderView::section {\n"
"    background-color: #4CAF50; /* Green header background */\n"
"    color: white; /* White text in header */\n"
"    padding: 8px;\n"
"    font-weight: bold;\n"
"    border: 1px solid #d0e7e7;\n"
"    border-radius: 0px;\n"
"}\n"
"\n"
"QTableCornerButton::section {\n"
"    background-color: #4CAF50; /* Match the header color */\n"
"    border: 1px solid #d0e7e7;\n"
"}\n"
"\n"
"/* S"
                        "crollbar */\n"
"QScrollBar:vertical {\n"
"    background: #f0f0f0;\n"
"    width: 12px;\n"
"    margin: 20px 0px 20px 0px; /* Adjust margins for scrollbar */\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"    background-color: #4CAF50; /* Green color */\n"
"    min-height: 20px;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"/* Scrollbar when hovered */\n"
"QScrollBar::handle:vertical:hover {\n"
"    background-color: #45a049; /* Slightly darker green on hover */\n"
"}\n"
"\n"
"QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"/* Row Hover Effect */\n"
"QTableWidget::item:hover {\n"
"    background-color: #a9d0f5; /* Light blue background when hovered */\n"
"    color: #000;\n"
"}\n"
"\n"
"/* Selected Row */\n"
"QTableWidget::item:selected {\n"
"    background-color: #87cefa; /* Light blue for selected row */\n"
"    color: white; /* White text when selected */\n"
"}\n"
"\n"
"/* Even rows */\n"
"QTableWidget::"
                        "item:!selected:even {\n"
"    background-color: #f0ffff; /* Light alternate row color */\n"
"}\n"
"\n"
"/* Odd rows */\n"
"QTableWidget::item:!selected:odd {\n"
"    background-color: #e7f7f7; /* Slightly darker alternate row color */\n"
"}\n"
"\n"
"/* Border for cells */\n"
"QTableWidget::item {\n"
"    border: 1px solid #d0e7e7; /* Border around table cells */\n"
"}\n"
""));
        a1 = new QWidget();
        a1->setObjectName(QString::fromUtf8("a1"));
        edit_2 = new QLineEdit(a1);
        edit_2->setObjectName(QString::fromUtf8("edit_2"));
        edit_2->setGeometry(QRect(550, 190, 141, 31));
        edit_2->setMinimumSize(QSize(0, 31));
        edit_2->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        tableWidget = new QTableWidget(a1);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/img/img/phone.svg"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        __qtablewidgetitem3->setIcon(icon1);
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget->rowCount() < 2)
            tableWidget->setRowCount(2);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/img/img/user.svg"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        __qtablewidgetitem6->setIcon(icon2);
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        __qtablewidgetitem7->setIcon(icon2);
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem8);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(410, 230, 701, 201));
        tableWidget->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        frame_3 = new QFrame(a1);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(0, 70, 401, 641));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        frame = new QFrame(frame_3);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(10, 60, 381, 571));
        frame->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251)"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        dateEdit = new QDateEdit(frame);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(120, 450, 111, 21));
        dateEdit->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        radioButton = new QRadioButton(frame);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(170, 360, 71, 21));
        radioButton->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        radioButton_3 = new QRadioButton(frame);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(250, 360, 81, 21));
        radioButton_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboBox = new QComboBox(frame);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(160, 250, 111, 28));
        comboBox->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_2 = new QPushButton(frame);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 510, 83, 41));
        pushButton_2->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_3 = new QPushButton(frame);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(240, 510, 83, 41));
        pushButton_3->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 30, 91, 21));
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_16 = new QLineEdit(frame);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(10, 120, 113, 28));
        lineEdit_16->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_5 = new QLabel(frame);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(170, 30, 71, 20));
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_6 = new QLabel(frame);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(170, 100, 63, 20));
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_7 = new QLabel(frame);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 99, 91, 21));
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_8 = new QLabel(frame);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(210, 331, 71, 20));
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_9 = new QLabel(frame);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(170, 160, 71, 20));
        label_9->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_10 = new QLabel(frame);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 160, 91, 21));
        label_10->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_11 = new QLabel(frame);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(10, 229, 91, 21));
        label_11->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_12 = new QLabel(frame);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 360, 91, 20));
        label_12->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_13 = new QLabel(frame);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 301, 111, 20));
        label_13->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        dateEdit_2 = new QDateEdit(frame);
        dateEdit_2->setObjectName(QString::fromUtf8("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(260, 450, 111, 21));
        dateEdit_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_44 = new QLabel(frame);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setGeometry(QRect(130, 410, 91, 21));
        label_44->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_45 = new QLabel(frame);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setGeometry(QRect(270, 410, 91, 21));
        label_45->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_46 = new QLabel(frame);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        label_46->setGeometry(QRect(170, 220, 91, 21));
        label_46->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_20 = new QPushButton(frame);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setGeometry(QRect(290, 70, 61, 51));
        pushButton_20->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_20{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_20{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_20:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_20:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/img/img/trash-2.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_20->setIcon(icon3);
        lineEdit_17 = new QLineEdit(frame);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(10, 50, 113, 28));
        lineEdit_17->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_20 = new QLineEdit(frame);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(10, 180, 113, 28));
        lineEdit_20->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_21 = new QLineEdit(frame);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(10, 250, 113, 28));
        lineEdit_21->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_22 = new QLineEdit(frame);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setGeometry(QRect(10, 320, 113, 28));
        lineEdit_22->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_39 = new QLineEdit(frame);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));
        lineEdit_39->setGeometry(QRect(10, 380, 113, 28));
        lineEdit_39->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_18 = new QLineEdit(frame);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setGeometry(QRect(160, 50, 113, 28));
        lineEdit_18->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_19 = new QLineEdit(frame);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(160, 120, 113, 28));
        lineEdit_19->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_40 = new QLineEdit(frame);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));
        lineEdit_40->setGeometry(QRect(160, 180, 113, 28));
        lineEdit_40->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_14 = new QLabel(frame_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(110, 30, 171, 41));
        label_14->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(160, 255, 228);"));
        label_15 = new QLabel(a1);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(410, 189, 131, 31));
        label_15->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_4 = new QPushButton(a1);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(700, 190, 83, 29));
        pushButton_4->setStyleSheet(QString::fromUtf8("QPushButton, #pushButton_4 {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"    color: rgba(255, 255, 255, 210);\n"
"    border-radius: 5px;\n"
"    transition: background-color 0.3s ease-in-out; /* Transition effect */\n"
"}\n"
"\n"
"QPushButton#pushButton_4:hover {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_4:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgba(150, 123, 111, 255);\n"
"    transition: background-color 0.1s ease-out; /* Faster transition when pressed */\n"
"}\n"
"\n"
"\n"
"\n"
"color: rgb(0, 0, 0);"));
        label_28 = new QLabel(a1);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(830, 190, 131, 31));
        label_28->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pic1 = new QLabel(a1);
        pic1->setObjectName(QString::fromUtf8("pic1"));
        pic1->setGeometry(QRect(420, 20, 591, 161));
        label_42 = new QLabel(a1);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setGeometry(QRect(590, 610, 31, 41));
        label_42->setPixmap(QPixmap(QString::fromUtf8(":/img/img/download.svg")));
        edit_5 = new QLineEdit(a1);
        edit_5->setObjectName(QString::fromUtf8("edit_5"));
        edit_5->setGeometry(QRect(740, 620, 141, 31));
        edit_5->setMinimumSize(QSize(0, 31));
        edit_5->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        pushButton_21 = new QPushButton(a1);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setGeometry(QRect(890, 600, 141, 61));
        pushButton_21->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_21{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_21:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_29 = new QPushButton(a1);
        pushButton_29->setObjectName(QString::fromUtf8("pushButton_29"));
        pushButton_29->setGeometry(QRect(430, 600, 141, 61));
        pushButton_29->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        label_66 = new QLabel(a1);
        label_66->setObjectName(QString::fromUtf8("label_66"));
        label_66->setGeometry(QRect(1020, 20, 161, 161));
        comboBox_3 = new QComboBox(a1);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/img/img/dollar-sign.svg"), QSize(), QIcon::Normal, QIcon::Off);
        comboBox_3->addItem(icon4, QString());
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/img/img/users.svg"), QSize(), QIcon::Normal, QIcon::Off);
        comboBox_3->addItem(icon5, QString());
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/img/img/award.svg"), QSize(), QIcon::Normal, QIcon::Off);
        comboBox_3->addItem(icon6, QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(970, 190, 82, 28));
        stackedWidget->addWidget(a1);
        a4 = new QWidget();
        a4->setObjectName(QString::fromUtf8("a4"));
        stackedWidget->addWidget(a4);
        a5 = new QWidget();
        a5->setObjectName(QString::fromUtf8("a5"));
        stackedWidget->addWidget(a5);
        a3 = new QWidget();
        a3->setObjectName(QString::fromUtf8("a3"));
        stackedWidget->addWidget(a3);
        a2 = new QWidget();
        a2->setObjectName(QString::fromUtf8("a2"));
        frame_11 = new QFrame(a2);
        frame_11->setObjectName(QString::fromUtf8("frame_11"));
        frame_11->setGeometry(QRect(20, 130, 401, 641));
        frame_11->setFrameShape(QFrame::StyledPanel);
        frame_11->setFrameShadow(QFrame::Raised);
        frame_12 = new QFrame(frame_11);
        frame_12->setObjectName(QString::fromUtf8("frame_12"));
        frame_12->setGeometry(QRect(10, 60, 381, 571));
        frame_12->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251)"));
        frame_12->setFrameShape(QFrame::StyledPanel);
        frame_12->setFrameShadow(QFrame::Raised);
        dateEdit_9 = new QDateEdit(frame_12);
        dateEdit_9->setObjectName(QString::fromUtf8("dateEdit_9"));
        dateEdit_9->setGeometry(QRect(120, 450, 111, 21));
        dateEdit_9->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        radioButton_9 = new QRadioButton(frame_12);
        radioButton_9->setObjectName(QString::fromUtf8("radioButton_9"));
        radioButton_9->setGeometry(QRect(170, 360, 71, 21));
        radioButton_9->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        radioButton_10 = new QRadioButton(frame_12);
        radioButton_10->setObjectName(QString::fromUtf8("radioButton_10"));
        radioButton_10->setGeometry(QRect(250, 360, 81, 21));
        radioButton_10->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboBox_7 = new QComboBox(frame_12);
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));
        comboBox_7->setGeometry(QRect(160, 250, 111, 28));
        comboBox_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_51 = new QLineEdit(frame_12);
        lineEdit_51->setObjectName(QString::fromUtf8("lineEdit_51"));
        lineEdit_51->setGeometry(QRect(160, 120, 113, 28));
        lineEdit_51->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_30 = new QPushButton(frame_12);
        pushButton_30->setObjectName(QString::fromUtf8("pushButton_30"));
        pushButton_30->setGeometry(QRect(40, 510, 83, 41));
        pushButton_30->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_31 = new QPushButton(frame_12);
        pushButton_31->setObjectName(QString::fromUtf8("pushButton_31"));
        pushButton_31->setGeometry(QRect(240, 510, 83, 41));
        pushButton_31->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        label_67 = new QLabel(frame_12);
        label_67->setObjectName(QString::fromUtf8("label_67"));
        label_67->setGeometry(QRect(10, 30, 91, 21));
        label_67->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_52 = new QLineEdit(frame_12);
        lineEdit_52->setObjectName(QString::fromUtf8("lineEdit_52"));
        lineEdit_52->setGeometry(QRect(10, 120, 113, 28));
        lineEdit_52->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_53 = new QLineEdit(frame_12);
        lineEdit_53->setObjectName(QString::fromUtf8("lineEdit_53"));
        lineEdit_53->setGeometry(QRect(10, 50, 113, 28));
        lineEdit_53->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_54 = new QLineEdit(frame_12);
        lineEdit_54->setObjectName(QString::fromUtf8("lineEdit_54"));
        lineEdit_54->setGeometry(QRect(160, 50, 113, 28));
        lineEdit_54->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_55 = new QLineEdit(frame_12);
        lineEdit_55->setObjectName(QString::fromUtf8("lineEdit_55"));
        lineEdit_55->setGeometry(QRect(160, 180, 113, 28));
        lineEdit_55->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_56 = new QLineEdit(frame_12);
        lineEdit_56->setObjectName(QString::fromUtf8("lineEdit_56"));
        lineEdit_56->setGeometry(QRect(10, 250, 113, 28));
        lineEdit_56->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_57 = new QLineEdit(frame_12);
        lineEdit_57->setObjectName(QString::fromUtf8("lineEdit_57"));
        lineEdit_57->setGeometry(QRect(10, 180, 113, 28));
        lineEdit_57->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_58 = new QLineEdit(frame_12);
        lineEdit_58->setObjectName(QString::fromUtf8("lineEdit_58"));
        lineEdit_58->setGeometry(QRect(10, 410, 113, 28));
        lineEdit_58->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_59 = new QLineEdit(frame_12);
        lineEdit_59->setObjectName(QString::fromUtf8("lineEdit_59"));
        lineEdit_59->setGeometry(QRect(10, 320, 113, 28));
        lineEdit_59->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_68 = new QLabel(frame_12);
        label_68->setObjectName(QString::fromUtf8("label_68"));
        label_68->setGeometry(QRect(170, 30, 71, 20));
        label_68->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_69 = new QLabel(frame_12);
        label_69->setObjectName(QString::fromUtf8("label_69"));
        label_69->setGeometry(QRect(170, 100, 63, 20));
        label_69->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_70 = new QLabel(frame_12);
        label_70->setObjectName(QString::fromUtf8("label_70"));
        label_70->setGeometry(QRect(10, 99, 91, 21));
        label_70->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_71 = new QLabel(frame_12);
        label_71->setObjectName(QString::fromUtf8("label_71"));
        label_71->setGeometry(QRect(210, 331, 71, 20));
        label_71->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_72 = new QLabel(frame_12);
        label_72->setObjectName(QString::fromUtf8("label_72"));
        label_72->setGeometry(QRect(170, 160, 71, 20));
        label_72->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_73 = new QLabel(frame_12);
        label_73->setObjectName(QString::fromUtf8("label_73"));
        label_73->setGeometry(QRect(10, 160, 91, 21));
        label_73->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_74 = new QLabel(frame_12);
        label_74->setObjectName(QString::fromUtf8("label_74"));
        label_74->setGeometry(QRect(10, 229, 91, 21));
        label_74->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_75 = new QLabel(frame_12);
        label_75->setObjectName(QString::fromUtf8("label_75"));
        label_75->setGeometry(QRect(10, 390, 91, 20));
        label_75->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_76 = new QLabel(frame_12);
        label_76->setObjectName(QString::fromUtf8("label_76"));
        label_76->setGeometry(QRect(10, 301, 111, 20));
        label_76->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        dateEdit_10 = new QDateEdit(frame_12);
        dateEdit_10->setObjectName(QString::fromUtf8("dateEdit_10"));
        dateEdit_10->setGeometry(QRect(260, 450, 111, 21));
        dateEdit_10->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_77 = new QLabel(frame_12);
        label_77->setObjectName(QString::fromUtf8("label_77"));
        label_77->setGeometry(QRect(130, 410, 91, 21));
        label_77->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_78 = new QLabel(frame_12);
        label_78->setObjectName(QString::fromUtf8("label_78"));
        label_78->setGeometry(QRect(270, 410, 91, 21));
        label_78->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_79 = new QLabel(frame_12);
        label_79->setObjectName(QString::fromUtf8("label_79"));
        label_79->setGeometry(QRect(170, 220, 91, 21));
        label_79->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_32 = new QPushButton(frame_12);
        pushButton_32->setObjectName(QString::fromUtf8("pushButton_32"));
        pushButton_32->setGeometry(QRect(290, 70, 61, 51));
        pushButton_32->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_30{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_30{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_30:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_30:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_32->setIcon(icon3);
        label_80 = new QLabel(frame_11);
        label_80->setObjectName(QString::fromUtf8("label_80"));
        label_80->setGeometry(QRect(110, 30, 171, 41));
        label_80->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(160, 255, 228);"));
        stackedWidget->addWidget(a2);

        horizontalLayout_3->addWidget(stackedWidget);


        verticalLayout_15->addWidget(main_screen_widget);


        gridLayout->addLayout(verticalLayout_15, 0, 2, 1, 1);

        icon_only_widget = new QWidget(layoutWidget);
        icon_only_widget->setObjectName(QString::fromUtf8("icon_only_widget"));
        icon_only_widget->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_14 = new QVBoxLayout(icon_only_widget);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        frame_2 = new QFrame(icon_only_widget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(frame_2);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        pushButton = new QPushButton(frame_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(16777215, 16777213));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8("../ressource/home.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon7);

        verticalLayout_13->addWidget(pushButton);

        p20 = new QPushButton(frame_2);
        p20->setObjectName(QString::fromUtf8("p20"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("../ressource/slack.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p20->setIcon(icon8);
        p20->setCheckable(true);
        p20->setAutoExclusive(true);

        verticalLayout_13->addWidget(p20);

        p21 = new QPushButton(frame_2);
        p21->setObjectName(QString::fromUtf8("p21"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8("../ressource/shopping-bag.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p21->setIcon(icon9);
        p21->setCheckable(true);
        p21->setAutoExclusive(true);

        verticalLayout_13->addWidget(p21);

        p22 = new QPushButton(frame_2);
        p22->setObjectName(QString::fromUtf8("p22"));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8("../ressource/heart.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p22->setIcon(icon10);
        p22->setCheckable(true);
        p22->setAutoExclusive(true);

        verticalLayout_13->addWidget(p22);

        p23 = new QPushButton(frame_2);
        p23->setObjectName(QString::fromUtf8("p23"));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8("../ressource/mail.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p23->setIcon(icon11);
        p23->setIconSize(QSize(50, 20));
        p23->setCheckable(true);
        p23->setAutoExclusive(true);

        verticalLayout_13->addWidget(p23);

        p24 = new QPushButton(frame_2);
        p24->setObjectName(QString::fromUtf8("p24"));
        QIcon icon12;
        icon12.addFile(QString::fromUtf8("../ressource/layers.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p24->setIcon(icon12);
        p24->setIconSize(QSize(50, 20));
        p24->setCheckable(true);
        p24->setAutoExclusive(true);

        verticalLayout_13->addWidget(p24);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_9);


        verticalLayout_14->addWidget(frame_2);

        pushButton_15 = new QPushButton(icon_only_widget);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        QIcon icon13;
        icon13.addFile(QString::fromUtf8("../ressource/settings.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_15->setIcon(icon13);
        pushButton_15->setCheckable(true);
        pushButton_15->setAutoExclusive(true);

        verticalLayout_14->addWidget(pushButton_15);

        pushButton_16 = new QPushButton(icon_only_widget);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/img/img/log-out.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_16->setIcon(icon14);
        pushButton_16->setCheckable(true);
        pushButton_16->setAutoExclusive(true);

        verticalLayout_14->addWidget(pushButton_16);


        gridLayout->addWidget(icon_only_widget, 0, 0, 1, 1);

        icon_names_text_widget = new QWidget(layoutWidget);
        icon_names_text_widget->setObjectName(QString::fromUtf8("icon_names_text_widget"));
        verticalLayout_16 = new QVBoxLayout(icon_names_text_widget);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        p9 = new QPushButton(icon_names_text_widget);
        p9->setObjectName(QString::fromUtf8("p9"));
        p9->setMaximumSize(QSize(16777215, 16777213));
        p9->setIcon(icon7);

        verticalLayout_16->addWidget(p9);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        RH = new QFrame(icon_names_text_widget);
        RH->setObjectName(QString::fromUtf8("RH"));
        RH->setFrameShape(QFrame::StyledPanel);
        RH->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(RH);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        p14 = new QPushButton(RH);
        p14->setObjectName(QString::fromUtf8("p14"));
        p14->setIcon(icon8);
        p14->setCheckable(true);

        verticalLayout_5->addWidget(p14);

        frame_rh = new QFrame(RH);
        frame_rh->setObjectName(QString::fromUtf8("frame_rh"));
        frame_rh->setFrameShape(QFrame::StyledPanel);
        frame_rh->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame_rh);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton_8 = new QPushButton(frame_rh);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setCheckable(true);

        verticalLayout->addWidget(pushButton_8);

        pushButton_9 = new QPushButton(frame_rh);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setCheckable(true);

        verticalLayout->addWidget(pushButton_9);

        pushButton_10 = new QPushButton(frame_rh);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setCheckable(true);

        verticalLayout->addWidget(pushButton_10);


        verticalLayout_5->addWidget(frame_rh);


        verticalLayout_9->addWidget(RH);

        SL = new QFrame(icon_names_text_widget);
        SL->setObjectName(QString::fromUtf8("SL"));
        SL->setFrameShape(QFrame::StyledPanel);
        SL->setFrameShadow(QFrame::Raised);
        verticalLayout_6 = new QVBoxLayout(SL);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        p11 = new QPushButton(SL);
        p11->setObjectName(QString::fromUtf8("p11"));
        p11->setIcon(icon9);
        p11->setCheckable(true);

        verticalLayout_6->addWidget(p11);

        frame_sales = new QFrame(SL);
        frame_sales->setObjectName(QString::fromUtf8("frame_sales"));
        frame_sales->setFrameShape(QFrame::StyledPanel);
        frame_sales->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(frame_sales);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        pushButton_11 = new QPushButton(frame_sales);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_11);

        pushButton_12 = new QPushButton(frame_sales);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_12);

        pushButton_14 = new QPushButton(frame_sales);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_14);


        verticalLayout_6->addWidget(frame_sales);


        verticalLayout_9->addWidget(SL);

        frame_9 = new QFrame(icon_names_text_widget);
        frame_9->setObjectName(QString::fromUtf8("frame_9"));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        verticalLayout_10 = new QVBoxLayout(frame_9);
        verticalLayout_10->setSpacing(0);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        pushButton_6 = new QPushButton(frame_9);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setIcon(icon10);
        pushButton_6->setCheckable(true);

        verticalLayout_10->addWidget(pushButton_6);

        frame_ord_2 = new QFrame(frame_9);
        frame_ord_2->setObjectName(QString::fromUtf8("frame_ord_2"));
        frame_ord_2->setFrameShape(QFrame::StyledPanel);
        frame_ord_2->setFrameShadow(QFrame::Raised);
        verticalLayout_11 = new QVBoxLayout(frame_ord_2);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        pushButton_35 = new QPushButton(frame_ord_2);
        pushButton_35->setObjectName(QString::fromUtf8("pushButton_35"));
        pushButton_35->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_35);

        pushButton_36 = new QPushButton(frame_ord_2);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_36);

        pushButton_37 = new QPushButton(frame_ord_2);
        pushButton_37->setObjectName(QString::fromUtf8("pushButton_37"));
        pushButton_37->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_37);


        verticalLayout_10->addWidget(frame_ord_2);


        verticalLayout_9->addWidget(frame_9);

        SK = new QFrame(icon_names_text_widget);
        SK->setObjectName(QString::fromUtf8("SK"));
        SK->setFrameShape(QFrame::StyledPanel);
        SK->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(SK);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        p13 = new QPushButton(SK);
        p13->setObjectName(QString::fromUtf8("p13"));
        p13->setIcon(icon11);
        p13->setIconSize(QSize(50, 20));
        p13->setCheckable(true);

        verticalLayout_7->addWidget(p13);

        frame_stc = new QFrame(SK);
        frame_stc->setObjectName(QString::fromUtf8("frame_stc"));
        frame_stc->setFrameShape(QFrame::StyledPanel);
        frame_stc->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_stc);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        pushButton_23 = new QPushButton(frame_stc);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_23);

        pushButton_24 = new QPushButton(frame_stc);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_24);

        pushButton_25 = new QPushButton(frame_stc);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_25);


        verticalLayout_7->addWidget(frame_stc);


        verticalLayout_9->addWidget(SK);

        frame_8 = new QFrame(icon_names_text_widget);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        verticalLayout_8 = new QVBoxLayout(frame_8);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        p10 = new QPushButton(frame_8);
        p10->setObjectName(QString::fromUtf8("p10"));
        p10->setIcon(icon12);
        p10->setCheckable(true);

        verticalLayout_8->addWidget(p10);

        frame_ord = new QFrame(frame_8);
        frame_ord->setObjectName(QString::fromUtf8("frame_ord"));
        frame_ord->setFrameShape(QFrame::StyledPanel);
        frame_ord->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(frame_ord);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        pushButton_26 = new QPushButton(frame_ord);
        pushButton_26->setObjectName(QString::fromUtf8("pushButton_26"));
        pushButton_26->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_26);

        pushButton_27 = new QPushButton(frame_ord);
        pushButton_27->setObjectName(QString::fromUtf8("pushButton_27"));
        pushButton_27->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_27);

        pushButton_28 = new QPushButton(frame_ord);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_28);


        verticalLayout_8->addWidget(frame_ord);


        verticalLayout_9->addWidget(frame_8);


        verticalLayout_16->addLayout(verticalLayout_9);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_12->addItem(verticalSpacer);

        p15 = new QPushButton(icon_names_text_widget);
        p15->setObjectName(QString::fromUtf8("p15"));
        p15->setIcon(icon13);
        p15->setCheckable(true);
        p15->setAutoExclusive(false);

        verticalLayout_12->addWidget(p15);

        p16 = new QPushButton(icon_names_text_widget);
        p16->setObjectName(QString::fromUtf8("p16"));
        p16->setIcon(icon14);
        p16->setCheckable(true);
        p16->setAutoExclusive(false);

        verticalLayout_12->addWidget(p16);


        verticalLayout_16->addLayout(verticalLayout_12);


        gridLayout->addWidget(icon_names_text_widget, 0, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(p14, &QPushButton::toggled, frame_rh, &QFrame::setHidden);
        QObject::connect(p11, &QPushButton::toggled, frame_sales, &QFrame::setHidden);
        QObject::connect(pushButton_6, &QPushButton::toggled, frame_ord_2, &QFrame::setHidden);
        QObject::connect(p13, &QPushButton::toggled, frame_stc, &QFrame::setHidden);
        QObject::connect(p10, &QPushButton::toggled, frame_ord, &QFrame::setHidden);
        QObject::connect(p9, &QPushButton::toggled, pushButton, &QPushButton::setChecked);
        QObject::connect(p14, &QPushButton::toggled, p20, &QPushButton::setChecked);
        QObject::connect(p11, &QPushButton::toggled, p21, &QPushButton::setChecked);
        QObject::connect(pushButton_6, &QPushButton::toggled, p22, &QPushButton::setChecked);
        QObject::connect(p13, &QPushButton::toggled, p23, &QPushButton::setChecked);
        QObject::connect(p10, &QPushButton::toggled, p24, &QPushButton::setChecked);
        QObject::connect(p16, &QPushButton::toggled, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(pushButton_16, &QPushButton::toggled, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(p16, &QPushButton::toggled, pushButton_16, &QPushButton::setChecked);
        QObject::connect(p15, &QPushButton::toggled, pushButton_15, &QPushButton::setChecked);
        QObject::connect(p17, &QPushButton::toggled, icon_names_text_widget, &QWidget::setHidden);
        QObject::connect(p17, &QPushButton::toggled, icon_only_widget, &QWidget::setVisible);
        QObject::connect(pushButton_20, &QPushButton::clicked, lineEdit_16, qOverload<>(&QLineEdit::clear));
        QObject::connect(pushButton_20, &QPushButton::clicked, lineEdit_17, qOverload<>(&QLineEdit::clear));

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        p17->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Hello", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Welcome to your page", nullptr));
        edit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Search here ...", nullptr));
        label_4->setText(QString());
        edit_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "id", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "cin", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "Adress", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "Phone Number", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "Date of hire", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "Role", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "client1", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "client2", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        tableWidget->setSortingEnabled(__sortingEnabled);

        radioButton->setText(QCoreApplication::translate("MainWindow", "Male", nullptr));
        radioButton_3->setText(QCoreApplication::translate("MainWindow", "Female", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("MainWindow", "Admin", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("MainWindow", "sales section", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("MainWindow", "order section", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("MainWindow", "commande section", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("MainWindow", "stock section", nullptr));

        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Modify", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Log in", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Password", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "CIN", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Gender", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Last name", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "First name", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Salary", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "Phone number", nullptr));
        label_44->setText(QCoreApplication::translate("MainWindow", "Date of Birth", nullptr));
        label_45->setText(QCoreApplication::translate("MainWindow", "Hire Date", nullptr));
        label_46->setText(QCoreApplication::translate("MainWindow", "Role", nullptr));
        pushButton_20->setText(QString());
        label_14->setText(QCoreApplication::translate("MainWindow", "Add or Update Employer", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        pic1->setText(QString());
        label_42->setText(QString());
        edit_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        pushButton_21->setText(QCoreApplication::translate("MainWindow", "Delete Employer", nullptr));
        pushButton_29->setText(QCoreApplication::translate("MainWindow", "Exporting PDF", nullptr));
        label_66->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        comboBox_3->setItemText(0, QCoreApplication::translate("MainWindow", "Salary", nullptr));
        comboBox_3->setItemText(1, QCoreApplication::translate("MainWindow", "Age", nullptr));
        comboBox_3->setItemText(2, QCoreApplication::translate("MainWindow", "Date of hire", nullptr));

        radioButton_9->setText(QCoreApplication::translate("MainWindow", "Male", nullptr));
        radioButton_10->setText(QCoreApplication::translate("MainWindow", "Female", nullptr));
        comboBox_7->setItemText(0, QCoreApplication::translate("MainWindow", "Admin", nullptr));
        comboBox_7->setItemText(1, QCoreApplication::translate("MainWindow", "sales section", nullptr));
        comboBox_7->setItemText(2, QCoreApplication::translate("MainWindow", "order section", nullptr));
        comboBox_7->setItemText(3, QCoreApplication::translate("MainWindow", "commande section", nullptr));
        comboBox_7->setItemText(4, QCoreApplication::translate("MainWindow", "stock section", nullptr));

        pushButton_30->setText(QCoreApplication::translate("MainWindow", "Modify", nullptr));
        pushButton_31->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_67->setText(QCoreApplication::translate("MainWindow", "Log in", nullptr));
        label_68->setText(QCoreApplication::translate("MainWindow", "Password", nullptr));
        label_69->setText(QCoreApplication::translate("MainWindow", "CIN", nullptr));
        label_70->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        label_71->setText(QCoreApplication::translate("MainWindow", "Gender", nullptr));
        label_72->setText(QCoreApplication::translate("MainWindow", "Last name", nullptr));
        label_73->setText(QCoreApplication::translate("MainWindow", "First name", nullptr));
        label_74->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        label_75->setText(QCoreApplication::translate("MainWindow", "Salary", nullptr));
        label_76->setText(QCoreApplication::translate("MainWindow", "Phone number", nullptr));
        label_77->setText(QCoreApplication::translate("MainWindow", "Date of Birth", nullptr));
        label_78->setText(QCoreApplication::translate("MainWindow", "Hire Date", nullptr));
        label_79->setText(QCoreApplication::translate("MainWindow", "Role", nullptr));
        pushButton_32->setText(QString());
        label_80->setText(QCoreApplication::translate("MainWindow", "Add or Update Employer", nullptr));
        pushButton->setText(QString());
        p20->setText(QString());
        p21->setText(QString());
        p22->setText(QString());
        p23->setText(QString());
        p24->setText(QString());
        pushButton_15->setText(QString());
        pushButton_16->setText(QString());
        p9->setText(QCoreApplication::translate("MainWindow", "home    ", nullptr));
        p14->setText(QCoreApplication::translate("MainWindow", "HR manager", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "Salairy", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p11->setText(QCoreApplication::translate("MainWindow", "Sales management", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Order Manager", nullptr));
        pushButton_35->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_36->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_37->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p13->setText(QCoreApplication::translate("MainWindow", "order management", nullptr));
        pushButton_23->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_24->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_25->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p10->setText(QCoreApplication::translate("MainWindow", "Stock management", nullptr));
        pushButton_26->setText(QCoreApplication::translate("MainWindow", "Recherch", nullptr));
        pushButton_27->setText(QCoreApplication::translate("MainWindow", "Ajout Emp", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "Statisque", nullptr));
        p15->setText(QCoreApplication::translate("MainWindow", " Settings", nullptr));
        p16->setText(QCoreApplication::translate("MainWindow", "Log out", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
