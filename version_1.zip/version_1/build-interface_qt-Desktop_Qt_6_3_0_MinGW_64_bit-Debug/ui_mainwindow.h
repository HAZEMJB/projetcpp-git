/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QWidget *icon_only_widget;
    QVBoxLayout *verticalLayout_14;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_13;
    QPushButton *pushButton;
    QPushButton *p20;
    QPushButton *p21;
    QPushButton *p22;
    QPushButton *p23;
    QPushButton *p24;
    QSpacerItem *verticalSpacer_9;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QVBoxLayout *verticalLayout_15;
    QWidget *heade_widget;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *p17;
    QLabel *label;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QLineEdit *edit;
    QLabel *label_4;
    QWidget *main_screen_widget;
    QHBoxLayout *horizontalLayout_3;
    QStackedWidget *stackedWidget;
    QWidget *a9;
    QLabel *label_35;
    QLabel *label_75;
    QWidget *a1;
    QFrame *frame_3;
    QFrame *frame;
    QPushButton *pushButton_2;
    QPushButton *add;
    QPushButton *pushButton_20;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_3;
    QLineEdit *lineEdit_17;
    QLabel *label_7;
    QLineEdit *lineEdit_16;
    QLabel *label_10;
    QLineEdit *lineEdit_20;
    QLabel *label_11;
    QLineEdit *lineEdit_21;
    QLabel *label_13;
    QLineEdit *lineEdit_22;
    QLabel *label_12;
    QLineEdit *lineEdit_39;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_5;
    QLineEdit *lineEdit_18;
    QLabel *label_6;
    QLineEdit *lineEdit_19;
    QLabel *label_9;
    QLineEdit *lineEdit_40;
    QLabel *label_46;
    QComboBox *comboBox;
    QLabel *label_8;
    QHBoxLayout *horizontalLayout_7;
    QRadioButton *radioButton;
    QRadioButton *radioButton_3;
    QHBoxLayout *horizontalLayout_8;
    QVBoxLayout *verticalLayout_20;
    QLabel *label_44;
    QDateEdit *dateEdit;
    QVBoxLayout *verticalLayout_21;
    QLabel *label_45;
    QDateEdit *dateEdit_2;
    QLabel *label_14;
    QLabel *pic1;
    QFrame *frame_7;
    QVBoxLayout *verticalLayout_17;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_15;
    QLineEdit *edit_2;
    QPushButton *pushButton_4;
    QLabel *label_28;
    QComboBox *comboBox_3;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButton_29;
    QLabel *label_42;
    QLineEdit *edit_5;
    QPushButton *pushButton_21;
    QWidget *a3_2;
    QLabel *label_34;
    QLabel *label_73;
    QWidget *page_wissal;
    QComboBox *comboBox_6;
    QComboBox *comboBox_8;
    QLineEdit *edit_8;
    QTableWidget *tableWidget_5;
    QLabel *label_39;
    QPushButton *pushButton_39;
    QLabel *label_47;
    QLineEdit *edit_9;
    QLabel *label_48;
    QPushButton *pushButton_26;
    QFrame *frame_13;
    QLineEdit *lineEdit_42;
    QLabel *label_51;
    QLineEdit *lineEdit_43;
    QLineEdit *lineEdit_46;
    QLineEdit *lineEdit_47;
    QLineEdit *lineEdit_48;
    QLabel *label_54;
    QLabel *label_55;
    QLabel *label_57;
    QLabel *label_58;
    QLabel *label_59;
    QScrollBar *horizontalScrollBar;
    QLineEdit *lineEdit_49;
    QLabel *label_60;
    QDateEdit *dateEdit_3;
    QPushButton *pushButton_7;
    QToolButton *toolButton;
    QPushButton *pushButton_3;
    QPushButton *pushButton_9;
    QLabel *label_52;
    QLabel *label_72;
    QWidget *page_xwis;
    QLabel *label_61;
    QWidget *a1_1;
    QFrame *frame_4;
    QLabel *label_70;
    QLabel *label_64;
    QLabel *label_71;
    QLabel *label_30;
    QWidget *a0_homepage;
    QLabel *pic1_3;
    QLabel *label_69;
    QWidget *a5;
    QFrame *frame_11;
    QFrame *frame_12;
    QPushButton *add_3;
    QLabel *label_40;
    QLineEdit *lineEdit_30;
    QLabel *label_41;
    QLabel *label_43;
    QLabel *label_50;
    QLabel *label_53;
    QPushButton *pushButton_32;
    QLineEdit *lineEdit_31;
    QLineEdit *lineEdit_32;
    QLineEdit *lineEdit_35;
    QDateEdit *dateEdit_6;
    QLabel *label_68;
    QTableWidget *tableWidget_3;
    QLabel *pic1_2;
    QPushButton *pushButton_34;
    QLineEdit *edit_6;
    QLabel *label_65;
    QPushButton *pushButton_38;
    QComboBox *comboBox_7;
    QLabel *label_66;
    QLineEdit *edit_3;
    QLabel *label_67;
    QPushButton *pushButton_13;
    QWidget *page;
    QLabel *label_56;
    QLabel *label_62;
    QLabel *label_74;
    QWidget *a3;
    QFrame *frame_5;
    QPushButton *pushButton_22;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *label_22;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_13;
    QLabel *label_23;
    QLineEdit *lineEdit_14;
    QLabel *label_25;
    QFrame *frame_6;
    QPushButton *aa;
    QPushButton *p9_3;
    QLabel *label_26;
    QPushButton *pushButton_30;
    QLineEdit *lineEdit_15;
    QComboBox *comboBox_2;
    QLabel *label_149;
    QDateEdit *dateEdit_11;
    QWidget *a3_1;
    QFrame *frame_10;
    QPushButton *aa_2;
    QPushButton *p9_4;
    QLineEdit *lineEdit;
    QPushButton *aa_3;
    QPushButton *aa_4;
    QLabel *label_27;
    QComboBox *comboBox_4;
    QTableWidget *tableWidget_2;
    QPushButton *aa_5;
    QPushButton *p9_5;
    QWidget *a2;
    QFrame *frame_14;
    QFrame *frame_15;
    QPushButton *add_2;
    QLabel *label_29;
    QLabel *label_33;
    QLabel *label_36;
    QLabel *label_37;
    QPushButton *pushButton_23;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_26;
    QDateEdit *dateEdit_4;
    QLabel *label_38;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_4;
    QLabel *label_24;
    QPushButton *add_5;
    QFrame *frame_16;
    QLabel *label_32;
    QLabel *label_31;
    QComboBox *comboBox_5;
    QTableWidget *tableWidget_4;
    QPushButton *pushButton_5;
    QLineEdit *edit_4;
    QLineEdit *edit_7;
    QLabel *label_49;
    QPushButton *pushButton_31;
    QPushButton *pushButton_33;
    QLabel *pic1_4;
    QWidget *icon_names_text_widget;
    QVBoxLayout *verticalLayout_16;
    QPushButton *p9;
    QVBoxLayout *verticalLayout_9;
    QFrame *RH;
    QVBoxLayout *verticalLayout_5;
    QPushButton *p14;
    QFrame *frame_rh;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_8;
    QPushButton *pushButton_10;
    QFrame *SL;
    QVBoxLayout *verticalLayout_6;
    QPushButton *p11;
    QFrame *frame_sales;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_12;
    QPushButton *pushButton_14;
    QFrame *frame_9;
    QVBoxLayout *verticalLayout_10;
    QPushButton *pushButton_6;
    QFrame *frame_ord_2;
    QVBoxLayout *verticalLayout_11;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QFrame *SK;
    QVBoxLayout *verticalLayout_7;
    QPushButton *p13;
    QFrame *frame_stc;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButton_25;
    QPushButton *pushButton_24;
    QFrame *frame_8;
    QVBoxLayout *verticalLayout_8;
    QPushButton *p10;
    QFrame *frame_ord;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButton_27;
    QPushButton *pushButton_28;
    QVBoxLayout *verticalLayout_12;
    QSpacerItem *verticalSpacer;
    QPushButton *p15;
    QPushButton *p16;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1627, 1015);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color:rgb(245,250,254);\n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("#edit{\n"
"	padding-left:20px;\n"
"	border:1px solid gray;	\n"
"	border-raduis:10px;\n"
"\n"
"}\n"
"#frame{\n"
"padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"#main_window_widget{\n"
"	background-color:rgb(131,255,189);\n"
"}\n"
"QPushButton#pushButton, #pushButton_6{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:hover, #pushButton_6:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed, #pushButton_6:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton, #p9 ,#p10 ,#p11 ,#p13 ,#p14{\n"
"	background-color: q"
                        "lineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:hover, #p9:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p9 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover, #p11:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p11 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover, #p10:hover{\n"
"	backgro"
                        "und-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed,  #p10 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#p14:hover, #p13:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p14:pressed,  #p13 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton #p14 ,#p15 ,#p16 ,#p17{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#p14:hover, #p15:hover{\n"
"	background-color: qlineargradi"
                        "ent(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p14:pressed,  #p15 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"QPushButton#p16:hover, #p17:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p16:pressed,  #p17 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#p20, #p21 ,#p22 ,#p23 ,#p24{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#p20:hover, #p21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:"
                        "0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p20:pressed,  #p21 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"QPushButton#p22:hover, #p23:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p22:pressed,  #p23 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"\n"
"\n"
"}\n"
"\n"
"QPushButton#p24:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#p24 :pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"/* Window "
                        "Background (main background) */\n"
"QWidget {\n"
"    background-color: qlineargradient(\n"
"        spread:pad, x1:0, y1:0, x2:1, y2:1, \n"
"        stop:0 rgba(30, 30, 60, 255), /* Dark blue at the top-left */\n"
"        stop:1 rgba(60, 90, 150, 255) /* Soft blue at the bottom-right */\n"
"    );\n"
"    color: #ffffff; /* White text color for contrast */\n"
"}\n"
"\n"
"/* Table Background (a bit transparent to show gradient) */\n"
"QTableWidget {\n"
"    background-color: rgba(255, 255, 255, 180); /* Slight transparency for table */\n"
"    alternate-background-color: rgba(255, 255, 255, 200); /* Transparent alternate rows */\n"
"    gridline-color: rgba(200, 200, 255, 180); /* Light gridlines */\n"
"    border: 1px solid rgba(255, 255, 255, 50); /* Subtle border */\n"
"}\n"
"\n"
"/* Header Background with a subtle glow effect */\n"
"QHeaderView::section {\n"
"    background-color: rgba(40, 60, 100, 255); /* Deep blue for headers */\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
""
                        "    border: 1px solid rgba(255, 255, 255, 60); /* Softer border */\n"
"}\n"
"\n"
"/* Buttons with a modern gradient and hover effect */\n"
"QPushButton {\n"
"    background-color: qlineargradient(\n"
"        spread:pad, x1:0, y1:0.5, x2:1, y2:0.5, \n"
"        stop:0 rgba(100, 120, 240, 255), \n"
"        stop:1 rgba(80, 100, 210, 255)\n"
"    );\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        spread:pad, x1:0, y1:0.5, x2:1, y2:0.5, \n"
"        stop:0 rgba(120, 150, 255, 255), \n"
"        stop:1 rgba(90, 130, 250, 255)\n"
"    );\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgba(80, 90, 180, 255); /* Darker blue when pressed */\n"
"}\n"
"\n"
"/* Scrollbar Customization */\n"
"QScrollBar:vertical {\n"
"    background: rgba(50, 50, 90, 255);\n"
"    border: none;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"    background: rgba(90, 110, 180, 255);\n"
"    min-height: 20px;\n"
""
                        "    border-radius: 5px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical:hover {\n"
"    background: rgba(120, 140, 200, 255);\n"
"}\n"
""));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, -20, 1501, 831));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        icon_only_widget = new QWidget(layoutWidget);
        icon_only_widget->setObjectName(QString::fromUtf8("icon_only_widget"));
        icon_only_widget->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_14 = new QVBoxLayout(icon_only_widget);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        frame_2 = new QFrame(icon_only_widget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(frame_2);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        pushButton = new QPushButton(frame_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(16777215, 16777213));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/img/img/home.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon);
        pushButton->setCheckable(true);

        verticalLayout_13->addWidget(pushButton);

        p20 = new QPushButton(frame_2);
        p20->setObjectName(QString::fromUtf8("p20"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/img/img/slack.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p20->setIcon(icon1);
        p20->setCheckable(true);
        p20->setAutoExclusive(true);

        verticalLayout_13->addWidget(p20);

        p21 = new QPushButton(frame_2);
        p21->setObjectName(QString::fromUtf8("p21"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/img/img/shopping-bag.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p21->setIcon(icon2);
        p21->setCheckable(true);
        p21->setAutoExclusive(true);

        verticalLayout_13->addWidget(p21);

        p22 = new QPushButton(frame_2);
        p22->setObjectName(QString::fromUtf8("p22"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/img/img/heart.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p22->setIcon(icon3);
        p22->setCheckable(true);
        p22->setAutoExclusive(true);

        verticalLayout_13->addWidget(p22);

        p23 = new QPushButton(frame_2);
        p23->setObjectName(QString::fromUtf8("p23"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/img/img/mail.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p23->setIcon(icon4);
        p23->setIconSize(QSize(50, 20));
        p23->setCheckable(true);
        p23->setAutoExclusive(true);

        verticalLayout_13->addWidget(p23);

        p24 = new QPushButton(frame_2);
        p24->setObjectName(QString::fromUtf8("p24"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/img/img/layers.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p24->setIcon(icon5);
        p24->setIconSize(QSize(50, 20));
        p24->setCheckable(true);
        p24->setAutoExclusive(true);

        verticalLayout_13->addWidget(p24);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_9);


        verticalLayout_14->addWidget(frame_2);

        pushButton_15 = new QPushButton(icon_only_widget);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/img/img/settings.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_15->setIcon(icon6);
        pushButton_15->setCheckable(true);
        pushButton_15->setAutoExclusive(true);

        verticalLayout_14->addWidget(pushButton_15);

        pushButton_16 = new QPushButton(icon_only_widget);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/img/img/log-out.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_16->setIcon(icon7);
        pushButton_16->setCheckable(true);
        pushButton_16->setAutoExclusive(true);

        verticalLayout_14->addWidget(pushButton_16);


        gridLayout->addWidget(icon_only_widget, 0, 0, 1, 1);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        heade_widget = new QWidget(layoutWidget);
        heade_widget->setObjectName(QString::fromUtf8("heade_widget"));
        horizontalLayout_4 = new QHBoxLayout(heade_widget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        p17 = new QPushButton(heade_widget);
        p17->setObjectName(QString::fromUtf8("p17"));
        p17->setMaximumSize(QSize(16777215, 16777213));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/img/img/align-justify.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p17->setIcon(icon8);
        p17->setCheckable(true);

        horizontalLayout_2->addWidget(p17);

        label = new QLabel(heade_widget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        label_2 = new QLabel(heade_widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font1;
        font1.setBold(true);
        label_2->setFont(font1);

        horizontalLayout_2->addWidget(label_2);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        edit = new QLineEdit(heade_widget);
        edit->setObjectName(QString::fromUtf8("edit"));
        edit->setMinimumSize(QSize(0, 31));
        edit->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"\n"
"}"));

        horizontalLayout->addWidget(edit);

        label_4 = new QLabel(heade_widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMaximumSize(QSize(40, 40));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/img/img/user.svg")));

        horizontalLayout->addWidget(label_4);


        horizontalLayout_4->addLayout(horizontalLayout);


        verticalLayout_15->addWidget(heade_widget);

        main_screen_widget = new QWidget(layoutWidget);
        main_screen_widget->setObjectName(QString::fromUtf8("main_screen_widget"));
        main_screen_widget->setMaximumSize(QSize(16777215, 16777215));
        main_screen_widget->setStyleSheet(QString::fromUtf8("background-color: rgb(12, 201, 218);"));
        horizontalLayout_3 = new QHBoxLayout(main_screen_widget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        stackedWidget = new QStackedWidget(main_screen_widget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setStyleSheet(QString::fromUtf8("\n"
"/* General Table Appearance */\n"
"QTableWidget {\n"
"    background-color: #e7f7f7; /* Light background for the table */\n"
"    alternate-background-color: #f0ffff; /* Lighter color for alternate rows */\n"
"    gridline-color: #d0e7e7; /* Soft gridline color */\n"
"    border: 2px solid #b0c4de; /* Border around the table */\n"
"    border-radius: 5px;\n"
"    font-size: 14px;\n"
"    color: #555; /* Text color */\n"
"    selection-background-color: #87cefa; /* Background color when a row is selected */\n"
"    selection-color: white; /* Text color when selected */\n"
"}\n"
"\n"
"/* Table Header */\n"
"QHeaderView::section {\n"
"    background-color: #4CAF50; /* Green header background */\n"
"    color: white; /* White text in header */\n"
"    padding: 8px;\n"
"    font-weight: bold;\n"
"    border: 1px solid #d0e7e7;\n"
"    border-radius: 0px;\n"
"}\n"
"\n"
"QTableCornerButton::section {\n"
"    background-color: #4CAF50; /* Match the header color */\n"
"    border: 1px solid #d0e7e7;\n"
"}\n"
"\n"
""
                        "/* Scrollbar */\n"
"QScrollBar:vertical {\n"
"    background: #f0f0f0;\n"
"    width: 12px;\n"
"    margin: 20px 0px 20px 0px; /* Adjust margins for scrollbar */\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"    background-color: #4CAF50; /* Green color */\n"
"    min-height: 20px;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"/* Scrollbar when hovered */\n"
"QScrollBar::handle:vertical:hover {\n"
"    background-color: #45a049; /* Slightly darker green on hover */\n"
"}\n"
"\n"
"QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"/* Row Hover Effect */\n"
"QTableWidget::item:hover {\n"
"    background-color: #a9d0f5; /* Light blue background when hovered */\n"
"    color: #000;\n"
"}\n"
"\n"
"/* Selected Row */\n"
"QTableWidget::item:selected {\n"
"    background-color: #87cefa; /* Light blue for selected row */\n"
"    color: white; /* White text when selected */\n"
"}\n"
"\n"
"/* Even rows */\n"
"QTableWidg"
                        "et::item:!selected:even {\n"
"    background-color: #f0ffff; /* Light alternate row color */\n"
"}\n"
"\n"
"/* Odd rows */\n"
"QTableWidget::item:!selected:odd {\n"
"    background-color: #e7f7f7; /* Slightly darker alternate row color */\n"
"}\n"
"\n"
"/* Border for cells */\n"
"QTableWidget::item {\n"
"    border: 1px solid #d0e7e7; /* Border around table cells */\n"
"}\n"
"\n"
"\n"
""));
        a9 = new QWidget();
        a9->setObjectName(QString::fromUtf8("a9"));
        label_35 = new QLabel(a9);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setGeometry(QRect(40, 140, 801, 541));
        label_35->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/siwar.jpeg")));
        label_75 = new QLabel(a9);
        label_75->setObjectName(QString::fromUtf8("label_75"));
        label_75->setGeometry(QRect(40, 40, 281, 91));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Segoe UI Variable Display Semib")});
        font2.setPointSize(25);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setUnderline(true);
        label_75->setFont(font2);
        stackedWidget->addWidget(a9);
        a1 = new QWidget();
        a1->setObjectName(QString::fromUtf8("a1"));
        frame_3 = new QFrame(a1);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(0, 70, 401, 641));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        frame = new QFrame(frame_3);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(10, 60, 381, 571));
        frame->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251)"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pushButton_2 = new QPushButton(frame);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 510, 83, 41));
        pushButton_2->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_2{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_2{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_2:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_2:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_2->setCheckable(true);
        add = new QPushButton(frame);
        add->setObjectName(QString::fromUtf8("add"));
        add->setGeometry(QRect(240, 510, 83, 41));
        add->setStyleSheet(QString::fromUtf8("\n"
"#add{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #add{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#add:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#add:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        add->setCheckable(true);
        pushButton_20 = new QPushButton(frame);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setGeometry(QRect(160, 500, 61, 51));
        pushButton_20->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_20{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_20{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_20:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_20:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/img/img/trash-2.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_20->setIcon(icon9);
        layoutWidget1 = new QWidget(frame);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 30, 127, 367));
        verticalLayout_18 = new QVBoxLayout(layoutWidget1);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        verticalLayout_18->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setStyleSheet(QString::fromUtf8("\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(label_3);

        lineEdit_17 = new QLineEdit(layoutWidget1);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(lineEdit_17);

        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(label_7);

        lineEdit_16 = new QLineEdit(layoutWidget1);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(lineEdit_16);

        label_10 = new QLabel(layoutWidget1);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(label_10);

        lineEdit_20 = new QLineEdit(layoutWidget1);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(lineEdit_20);

        label_11 = new QLabel(layoutWidget1);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(label_11);

        lineEdit_21 = new QLineEdit(layoutWidget1);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(lineEdit_21);

        label_13 = new QLabel(layoutWidget1);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(label_13);

        lineEdit_22 = new QLineEdit(layoutWidget1);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(lineEdit_22);

        label_12 = new QLabel(layoutWidget1);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(label_12);

        lineEdit_39 = new QLineEdit(layoutWidget1);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));
        lineEdit_39->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_18->addWidget(lineEdit_39);

        layoutWidget2 = new QWidget(frame);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(160, 30, 223, 371));
        verticalLayout_19 = new QVBoxLayout(layoutWidget2);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        verticalLayout_19->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(label_5);

        lineEdit_18 = new QLineEdit(layoutWidget2);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(lineEdit_18);

        label_6 = new QLabel(layoutWidget2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(label_6);

        lineEdit_19 = new QLineEdit(layoutWidget2);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(lineEdit_19);

        label_9 = new QLabel(layoutWidget2);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(label_9);

        lineEdit_40 = new QLineEdit(layoutWidget2);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));
        lineEdit_40->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(lineEdit_40);

        label_46 = new QLabel(layoutWidget2);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        label_46->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(label_46);

        comboBox = new QComboBox(layoutWidget2);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(comboBox);

        label_8 = new QLabel(layoutWidget2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_19->addWidget(label_8);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        radioButton = new QRadioButton(layoutWidget2);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        horizontalLayout_7->addWidget(radioButton);

        radioButton_3 = new QRadioButton(layoutWidget2);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        horizontalLayout_7->addWidget(radioButton_3);


        verticalLayout_19->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        label_44 = new QLabel(layoutWidget2);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_20->addWidget(label_44);

        dateEdit = new QDateEdit(layoutWidget2);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_20->addWidget(dateEdit);


        horizontalLayout_8->addLayout(verticalLayout_20);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        label_45 = new QLabel(layoutWidget2);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_21->addWidget(label_45);

        dateEdit_2 = new QDateEdit(layoutWidget2);
        dateEdit_2->setObjectName(QString::fromUtf8("dateEdit_2"));
        dateEdit_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_21->addWidget(dateEdit_2);


        horizontalLayout_8->addLayout(verticalLayout_21);


        verticalLayout_19->addLayout(horizontalLayout_8);

        label_14 = new QLabel(frame_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(110, 30, 171, 41));
        label_14->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(160, 255, 228);"));
        pic1 = new QLabel(a1);
        pic1->setObjectName(QString::fromUtf8("pic1"));
        pic1->setGeometry(QRect(420, 30, 601, 151));
        pic1->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/aze.png")));
        frame_7 = new QFrame(a1);
        frame_7->setObjectName(QString::fromUtf8("frame_7"));
        frame_7->setGeometry(QRect(410, 190, 721, 471));
        frame_7->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251);\n"
"border-radius:15px;\n"
""));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        verticalLayout_17 = new QVBoxLayout(frame_7);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_15 = new QLabel(frame_7);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        horizontalLayout_5->addWidget(label_15);

        edit_2 = new QLineEdit(frame_7);
        edit_2->setObjectName(QString::fromUtf8("edit_2"));
        edit_2->setMinimumSize(QSize(0, 31));
        edit_2->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));

        horizontalLayout_5->addWidget(edit_2);

        pushButton_4 = new QPushButton(frame_7);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setStyleSheet(QString::fromUtf8("QPushButton, #pushButton_4 {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"    color: rgba(255, 255, 255, 210);\n"
"    border-radius: 5px;\n"
"    transition: background-color 0.3s ease-in-out; /* Transition effect */\n"
"}\n"
"\n"
"QPushButton#pushButton_4:hover {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_4:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgba(150, 123, 111, 255);\n"
"    transition: background-color 0.1s ease-out; /* Faster transition when pressed */\n"
"}\n"
"\n"
"\n"
"\n"
"color: rgb(0, 0, 0);"));

        horizontalLayout_5->addWidget(pushButton_4);

        label_28 = new QLabel(frame_7);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        horizontalLayout_5->addWidget(label_28);

        comboBox_3 = new QComboBox(frame_7);
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/img/img/dollar-sign.svg"), QSize(), QIcon::Normal, QIcon::Off);
        comboBox_3->addItem(icon10, QString());
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/img/img/users.svg"), QSize(), QIcon::Normal, QIcon::Off);
        comboBox_3->addItem(icon11, QString());
        QIcon icon12;
        icon12.addFile(QString::fromUtf8(":/img/img/award.svg"), QSize(), QIcon::Normal, QIcon::Off);
        comboBox_3->addItem(icon12, QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));

        horizontalLayout_5->addWidget(comboBox_3);


        verticalLayout_17->addLayout(horizontalLayout_5);

        tableWidget = new QTableWidget(frame_7);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QIcon icon13;
        icon13.addFile(QString::fromUtf8(":/img/img/phone.svg"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        __qtablewidgetitem3->setIcon(icon13);
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget->rowCount() < 6)
            tableWidget->setRowCount(6);
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/img/img/user.svg"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        __qtablewidgetitem6->setIcon(icon14);
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        __qtablewidgetitem7->setIcon(icon14);
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(4, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(5, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem12);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        verticalLayout_17->addWidget(tableWidget);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        pushButton_29 = new QPushButton(frame_7);
        pushButton_29->setObjectName(QString::fromUtf8("pushButton_29"));
        pushButton_29->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));

        horizontalLayout_6->addWidget(pushButton_29);

        label_42 = new QLabel(frame_7);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setPixmap(QPixmap(QString::fromUtf8(":/img/img/download.svg")));

        horizontalLayout_6->addWidget(label_42);

        edit_5 = new QLineEdit(frame_7);
        edit_5->setObjectName(QString::fromUtf8("edit_5"));
        edit_5->setMinimumSize(QSize(0, 31));
        edit_5->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));

        horizontalLayout_6->addWidget(edit_5);

        pushButton_21 = new QPushButton(frame_7);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_21{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_21:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));

        horizontalLayout_6->addWidget(pushButton_21);


        verticalLayout_17->addLayout(horizontalLayout_6);

        stackedWidget->addWidget(a1);
        a3_2 = new QWidget();
        a3_2->setObjectName(QString::fromUtf8("a3_2"));
        label_34 = new QLabel(a3_2);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setGeometry(QRect(40, 210, 711, 531));
        label_34->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/hazem.jpeg")));
        label_73 = new QLabel(a3_2);
        label_73->setObjectName(QString::fromUtf8("label_73"));
        label_73->setGeometry(QRect(120, 100, 281, 91));
        label_73->setFont(font2);
        stackedWidget->addWidget(a3_2);
        page_wissal = new QWidget();
        page_wissal->setObjectName(QString::fromUtf8("page_wissal"));
        comboBox_6 = new QComboBox(page_wissal);
        comboBox_6->addItem(QString());
        comboBox_6->addItem(QString());
        comboBox_6->addItem(QString());
        comboBox_6->addItem(QString());
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));
        comboBox_6->setGeometry(QRect(520, 510, 111, 28));
        comboBox_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboBox_8 = new QComboBox(page_wissal);
        comboBox_8->addItem(QString());
        comboBox_8->setObjectName(QString::fromUtf8("comboBox_8"));
        comboBox_8->setGeometry(QRect(490, 460, 111, 28));
        comboBox_8->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        edit_8 = new QLineEdit(page_wissal);
        edit_8->setObjectName(QString::fromUtf8("edit_8"));
        edit_8->setGeometry(QRect(570, 200, 141, 31));
        edit_8->setMinimumSize(QSize(0, 31));
        edit_8->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        tableWidget_5 = new QTableWidget(page_wissal);
        if (tableWidget_5->columnCount() < 5)
            tableWidget_5->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(0, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(1, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(2, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(3, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(4, __qtablewidgetitem17);
        if (tableWidget_5->rowCount() < 2)
            tableWidget_5->setRowCount(2);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        __qtablewidgetitem18->setIcon(icon14);
        tableWidget_5->setVerticalHeaderItem(0, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        __qtablewidgetitem19->setIcon(icon14);
        tableWidget_5->setVerticalHeaderItem(1, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget_5->setItem(0, 0, __qtablewidgetitem20);
        tableWidget_5->setObjectName(QString::fromUtf8("tableWidget_5"));
        tableWidget_5->setGeometry(QRect(430, 240, 701, 201));
        tableWidget_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_39 = new QLabel(page_wissal);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setGeometry(QRect(820, 200, 131, 31));
        label_39->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_39 = new QPushButton(page_wissal);
        pushButton_39->setObjectName(QString::fromUtf8("pushButton_39"));
        pushButton_39->setGeometry(QRect(970, 620, 141, 61));
        pushButton_39->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_22{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_22:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_22:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon15;
        QString iconThemeName = QString::fromUtf8("QIcon::ThemeIcon::FormatJustifyRight");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon15 = QIcon::fromTheme(iconThemeName);
        } else {
            icon15.addFile(QString::fromUtf8("../../../Downloads"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_39->setIcon(icon15);
        label_47 = new QLabel(page_wissal);
        label_47->setObjectName(QString::fromUtf8("label_47"));
        label_47->setGeometry(QRect(430, 510, 91, 31));
        label_47->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        edit_9 = new QLineEdit(page_wissal);
        edit_9->setObjectName(QString::fromUtf8("edit_9"));
        edit_9->setGeometry(QRect(970, 200, 141, 31));
        edit_9->setMinimumSize(QSize(0, 31));
        edit_9->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        label_48 = new QLabel(page_wissal);
        label_48->setObjectName(QString::fromUtf8("label_48"));
        label_48->setGeometry(QRect(450, 460, 41, 31));
        label_48->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_26 = new QPushButton(page_wissal);
        pushButton_26->setObjectName(QString::fromUtf8("pushButton_26"));
        pushButton_26->setGeometry(QRect(810, 620, 141, 61));
        pushButton_26->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_22{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_22:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_22:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon16;
        iconThemeName = QString::fromUtf8("QIcon::ThemeIcon::DocumentPrintPreview");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon16 = QIcon::fromTheme(iconThemeName);
        } else {
            icon16.addFile(QString::fromUtf8("../../../Downloads"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_26->setIcon(icon16);
        frame_13 = new QFrame(page_wissal);
        frame_13->setObjectName(QString::fromUtf8("frame_13"));
        frame_13->setGeometry(QRect(20, 90, 381, 581));
        frame_13->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251)"));
        frame_13->setFrameShape(QFrame::NoFrame);
        lineEdit_42 = new QLineEdit(frame_13);
        lineEdit_42->setObjectName(QString::fromUtf8("lineEdit_42"));
        lineEdit_42->setGeometry(QRect(160, 90, 113, 28));
        lineEdit_42->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_51 = new QLabel(frame_13);
        label_51->setObjectName(QString::fromUtf8("label_51"));
        label_51->setGeometry(QRect(10, 30, 91, 21));
        label_51->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_43 = new QLineEdit(frame_13);
        lineEdit_43->setObjectName(QString::fromUtf8("lineEdit_43"));
        lineEdit_43->setGeometry(QRect(10, 90, 113, 28));
        lineEdit_43->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_46 = new QLineEdit(frame_13);
        lineEdit_46->setObjectName(QString::fromUtf8("lineEdit_46"));
        lineEdit_46->setGeometry(QRect(160, 180, 113, 28));
        lineEdit_46->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_47 = new QLineEdit(frame_13);
        lineEdit_47->setObjectName(QString::fromUtf8("lineEdit_47"));
        lineEdit_47->setGeometry(QRect(10, 270, 113, 28));
        lineEdit_47->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_48 = new QLineEdit(frame_13);
        lineEdit_48->setObjectName(QString::fromUtf8("lineEdit_48"));
        lineEdit_48->setGeometry(QRect(10, 180, 113, 28));
        lineEdit_48->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_54 = new QLabel(frame_13);
        label_54->setObjectName(QString::fromUtf8("label_54"));
        label_54->setGeometry(QRect(20, 150, 63, 20));
        label_54->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_55 = new QLabel(frame_13);
        label_55->setObjectName(QString::fromUtf8("label_55"));
        label_55->setGeometry(QRect(20, 60, 91, 21));
        label_55->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_57 = new QLabel(frame_13);
        label_57->setObjectName(QString::fromUtf8("label_57"));
        label_57->setGeometry(QRect(170, 150, 71, 20));
        label_57->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_58 = new QLabel(frame_13);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        label_58->setGeometry(QRect(170, 60, 91, 21));
        label_58->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_59 = new QLabel(frame_13);
        label_59->setObjectName(QString::fromUtf8("label_59"));
        label_59->setGeometry(QRect(10, 240, 91, 21));
        label_59->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        horizontalScrollBar = new QScrollBar(frame_13);
        horizontalScrollBar->setObjectName(QString::fromUtf8("horizontalScrollBar"));
        horizontalScrollBar->setGeometry(QRect(0, 560, 381, 20));
        lineEdit_49 = new QLineEdit(frame_13);
        lineEdit_49->setObjectName(QString::fromUtf8("lineEdit_49"));
        lineEdit_49->setGeometry(QRect(160, 270, 113, 28));
        lineEdit_49->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_60 = new QLabel(frame_13);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        label_60->setGeometry(QRect(170, 240, 91, 21));
        label_60->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        dateEdit_3 = new QDateEdit(frame_13);
        dateEdit_3->setObjectName(QString::fromUtf8("dateEdit_3"));
        dateEdit_3->setGeometry(QRect(160, 270, 110, 26));
        pushButton_7 = new QPushButton(frame_13);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(80, 470, 131, 41));
        pushButton_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        toolButton = new QToolButton(frame_13);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setGeometry(QRect(220, 470, 24, 26));
        pushButton_3 = new QPushButton(frame_13);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(60, 360, 91, 51));
        pushButton_9 = new QPushButton(frame_13);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(160, 360, 101, 51));
        label_52 = new QLabel(page_wissal);
        label_52->setObjectName(QString::fromUtf8("label_52"));
        label_52->setGeometry(QRect(430, 199, 131, 31));
        label_52->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_72 = new QLabel(page_wissal);
        label_72->setObjectName(QString::fromUtf8("label_72"));
        label_72->setGeometry(QRect(100, 70, 191, 41));
        label_72->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(160, 255, 228);"));
        stackedWidget->addWidget(page_wissal);
        page_xwis = new QWidget();
        page_xwis->setObjectName(QString::fromUtf8("page_xwis"));
        label_61 = new QLabel(page_xwis);
        label_61->setObjectName(QString::fromUtf8("label_61"));
        label_61->setGeometry(QRect(30, 130, 751, 461));
        stackedWidget->addWidget(page_xwis);
        a1_1 = new QWidget();
        a1_1->setObjectName(QString::fromUtf8("a1_1"));
        frame_4 = new QFrame(a1_1);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setGeometry(QRect(10, 20, 1051, 721));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        label_70 = new QLabel(frame_4);
        label_70->setObjectName(QString::fromUtf8("label_70"));
        label_70->setGeometry(QRect(30, 20, 281, 91));
        label_70->setFont(font2);
        label_64 = new QLabel(frame_4);
        label_64->setObjectName(QString::fromUtf8("label_64"));
        label_64->setGeometry(QRect(60, 330, 321, 281));
        label_64->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/stt.png")));
        label_71 = new QLabel(frame_4);
        label_71->setObjectName(QString::fromUtf8("label_71"));
        label_71->setGeometry(QRect(490, 300, 481, 361));
        label_71->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/avc.png")));
        label_30 = new QLabel(frame_4);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(360, 0, 681, 211));
        label_30->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/stat.png")));
        stackedWidget->addWidget(a1_1);
        a0_homepage = new QWidget();
        a0_homepage->setObjectName(QString::fromUtf8("a0_homepage"));
        pic1_3 = new QLabel(a0_homepage);
        pic1_3->setObjectName(QString::fromUtf8("pic1_3"));
        pic1_3->setGeometry(QRect(170, 30, 781, 281));
        pic1_3->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/aze.png")));
        label_69 = new QLabel(a0_homepage);
        label_69->setObjectName(QString::fromUtf8("label_69"));
        label_69->setGeometry(QRect(170, 340, 681, 211));
        QFont font3;
        font3.setPointSize(31);
        font3.setBold(true);
        label_69->setFont(font3);
        label_69->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        stackedWidget->addWidget(a0_homepage);
        a5 = new QWidget();
        a5->setObjectName(QString::fromUtf8("a5"));
        frame_11 = new QFrame(a5);
        frame_11->setObjectName(QString::fromUtf8("frame_11"));
        frame_11->setGeometry(QRect(10, 20, 1061, 771));
        frame_11->setFrameShape(QFrame::StyledPanel);
        frame_11->setFrameShadow(QFrame::Raised);
        frame_12 = new QFrame(frame_11);
        frame_12->setObjectName(QString::fromUtf8("frame_12"));
        frame_12->setGeometry(QRect(10, 110, 381, 571));
        frame_12->setStyleSheet(QString::fromUtf8("background-color: rgb(202, 255, 251);\n"
"border-radius:20px;"));
        frame_12->setFrameShape(QFrame::StyledPanel);
        frame_12->setFrameShadow(QFrame::Raised);
        add_3 = new QPushButton(frame_12);
        add_3->setObjectName(QString::fromUtf8("add_3"));
        add_3->setGeometry(QRect(200, 390, 83, 41));
        add_3->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        add_3->setCheckable(true);
        label_40 = new QLabel(frame_12);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setGeometry(QRect(10, 30, 101, 21));
        label_40->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_30 = new QLineEdit(frame_12);
        lineEdit_30->setObjectName(QString::fromUtf8("lineEdit_30"));
        lineEdit_30->setGeometry(QRect(10, 120, 113, 28));
        lineEdit_30->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_41 = new QLabel(frame_12);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        label_41->setGeometry(QRect(10, 230, 81, 20));
        label_41->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_43 = new QLabel(frame_12);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setGeometry(QRect(10, 300, 111, 20));
        label_43->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_50 = new QLabel(frame_12);
        label_50->setObjectName(QString::fromUtf8("label_50"));
        label_50->setGeometry(QRect(10, 99, 91, 21));
        label_50->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_53 = new QLabel(frame_12);
        label_53->setObjectName(QString::fromUtf8("label_53"));
        label_53->setGeometry(QRect(10, 160, 91, 21));
        label_53->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_32 = new QPushButton(frame_12);
        pushButton_32->setObjectName(QString::fromUtf8("pushButton_32"));
        pushButton_32->setGeometry(QRect(290, 70, 61, 51));
        pushButton_32->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_20{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_20{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_20:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_20:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_32->setIcon(icon9);
        lineEdit_31 = new QLineEdit(frame_12);
        lineEdit_31->setObjectName(QString::fromUtf8("lineEdit_31"));
        lineEdit_31->setGeometry(QRect(10, 50, 113, 28));
        lineEdit_31->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_32 = new QLineEdit(frame_12);
        lineEdit_32->setObjectName(QString::fromUtf8("lineEdit_32"));
        lineEdit_32->setGeometry(QRect(10, 180, 113, 28));
        lineEdit_32->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_35 = new QLineEdit(frame_12);
        lineEdit_35->setObjectName(QString::fromUtf8("lineEdit_35"));
        lineEdit_35->setGeometry(QRect(10, 250, 113, 28));
        lineEdit_35->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        dateEdit_6 = new QDateEdit(frame_12);
        dateEdit_6->setObjectName(QString::fromUtf8("dateEdit_6"));
        dateEdit_6->setGeometry(QRect(10, 320, 110, 29));
        dateEdit_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_68 = new QLabel(frame_12);
        label_68->setObjectName(QString::fromUtf8("label_68"));
        label_68->setGeometry(QRect(150, 0, 101, 41));
        label_68->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(160, 255, 228);"));
        tableWidget_3 = new QTableWidget(frame_11);
        if (tableWidget_3->columnCount() < 5)
            tableWidget_3->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(0, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(1, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(2, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(3, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(4, __qtablewidgetitem25);
        if (tableWidget_3->rowCount() < 2)
            tableWidget_3->setRowCount(2);
        QIcon icon17;
        icon17.addFile(QString::fromUtf8(":/img/img/hexagon.svg"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        __qtablewidgetitem26->setIcon(icon17);
        tableWidget_3->setVerticalHeaderItem(0, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        __qtablewidgetitem27->setIcon(icon17);
        tableWidget_3->setVerticalHeaderItem(1, __qtablewidgetitem27);
        tableWidget_3->setObjectName(QString::fromUtf8("tableWidget_3"));
        tableWidget_3->setGeometry(QRect(400, 260, 701, 201));
        tableWidget_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pic1_2 = new QLabel(frame_11);
        pic1_2->setObjectName(QString::fromUtf8("pic1_2"));
        pic1_2->setGeometry(QRect(400, 40, 601, 151));
        pic1_2->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/aze.png")));
        pushButton_34 = new QPushButton(frame_11);
        pushButton_34->setObjectName(QString::fromUtf8("pushButton_34"));
        pushButton_34->setGeometry(QRect(890, 520, 141, 61));
        pushButton_34->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_21{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_21:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        edit_6 = new QLineEdit(frame_11);
        edit_6->setObjectName(QString::fromUtf8("edit_6"));
        edit_6->setGeometry(QRect(740, 540, 141, 31));
        edit_6->setMinimumSize(QSize(0, 31));
        edit_6->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        label_65 = new QLabel(frame_11);
        label_65->setObjectName(QString::fromUtf8("label_65"));
        label_65->setGeometry(QRect(590, 530, 31, 41));
        label_65->setPixmap(QPixmap(QString::fromUtf8(":/img/img/download.svg")));
        pushButton_38 = new QPushButton(frame_11);
        pushButton_38->setObjectName(QString::fromUtf8("pushButton_38"));
        pushButton_38->setGeometry(QRect(430, 520, 141, 61));
        pushButton_38->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        comboBox_7 = new QComboBox(frame_11);
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));
        comboBox_7->setGeometry(QRect(950, 207, 131, 31));
        label_66 = new QLabel(frame_11);
        label_66->setObjectName(QString::fromUtf8("label_66"));
        label_66->setGeometry(QRect(400, 199, 131, 41));
        label_66->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        edit_3 = new QLineEdit(frame_11);
        edit_3->setObjectName(QString::fromUtf8("edit_3"));
        edit_3->setGeometry(QRect(540, 200, 151, 41));
        edit_3->setMinimumSize(QSize(0, 31));
        edit_3->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        label_67 = new QLabel(frame_11);
        label_67->setObjectName(QString::fromUtf8("label_67"));
        label_67->setGeometry(QRect(800, 200, 151, 41));
        label_67->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_13 = new QPushButton(frame_11);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(710, 200, 83, 41));
        pushButton_13->setStyleSheet(QString::fromUtf8("QPushButton, #pushButton_4 {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"    color: rgba(255, 255, 255, 210);\n"
"    border-radius: 5px;\n"
"    transition: background-color 0.3s ease-in-out; /* Transition effect */\n"
"}\n"
"\n"
"QPushButton#pushButton_4:hover {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_4:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgba(150, 123, 111, 255);\n"
"    transition: background-color 0.1s ease-out; /* Faster transition when pressed */\n"
"}\n"
"\n"
"\n"
"\n"
"color: rgb(0, 0, 0);"));
        stackedWidget->addWidget(a5);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        label_56 = new QLabel(page);
        label_56->setObjectName(QString::fromUtf8("label_56"));
        label_56->setGeometry(QRect(-10, 300, 631, 481));
        label_56->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/mariem.jpeg")));
        label_62 = new QLabel(page);
        label_62->setObjectName(QString::fromUtf8("label_62"));
        label_62->setGeometry(QRect(630, 410, 521, 371));
        label_62->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/mariem1.jpeg")));
        label_74 = new QLabel(page);
        label_74->setObjectName(QString::fromUtf8("label_74"));
        label_74->setGeometry(QRect(100, 160, 281, 91));
        label_74->setFont(font2);
        stackedWidget->addWidget(page);
        a3 = new QWidget();
        a3->setObjectName(QString::fromUtf8("a3"));
        frame_5 = new QFrame(a3);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setGeometry(QRect(50, 40, 981, 721));
        frame_5->setStyleSheet(QString::fromUtf8("\n"
"\n"
"background-color: rgb(202, 255, 251);\n"
"border-radius:20px;"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        pushButton_22 = new QPushButton(frame_5);
        pushButton_22->setObjectName(QString::fromUtf8("pushButton_22"));
        pushButton_22->setGeometry(QRect(770, 50, 61, 51));
        pushButton_22->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_20{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_20{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_20:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_20:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_22->setIcon(icon9);
        pushButton_22->setCheckable(true);
        pushButton_22->setAutoExclusive(true);
        label_16 = new QLabel(frame_5);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(40, 110, 111, 31));
        QFont font4;
        font4.setFamilies({QString::fromUtf8("Bell MT")});
        font4.setPointSize(12);
        font4.setBold(false);
        label_16->setFont(font4);
        label_16->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
""));
        label_17 = new QLabel(frame_5);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(40, 170, 111, 31));
        label_17->setFont(font4);
        label_17->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_18 = new QLabel(frame_5);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(40, 230, 111, 31));
        label_18->setFont(font4);
        label_18->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_19 = new QLabel(frame_5);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(40, 290, 141, 31));
        label_19->setFont(font4);
        label_19->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_20 = new QLabel(frame_5);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(40, 420, 131, 31));
        label_20->setFont(font4);
        label_20->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_21 = new QLabel(frame_5);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(340, 420, 111, 31));
        label_21->setFont(font4);
        label_21->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_22 = new QLabel(frame_5);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(40, 350, 131, 31));
        label_22->setFont(font4);
        label_22->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_7 = new QLineEdit(frame_5);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(190, 350, 113, 28));
        lineEdit_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_8 = new QLineEdit(frame_5);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(460, 420, 281, 28));
        lineEdit_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_11 = new QLineEdit(frame_5);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(190, 230, 113, 28));
        lineEdit_11->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_12 = new QLineEdit(frame_5);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(190, 170, 113, 28));
        lineEdit_12->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_13 = new QLineEdit(frame_5);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(190, 110, 113, 28));
        lineEdit_13->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_23 = new QLabel(frame_5);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(340, 100, 161, 31));
        label_23->setFont(font4);
        label_23->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEdit_14 = new QLineEdit(frame_5);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(570, 100, 151, 28));
        lineEdit_14->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_25 = new QLabel(frame_5);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(340, 180, 201, 31));
        label_25->setFont(font4);
        label_25->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        frame_6 = new QFrame(frame_5);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        frame_6->setGeometry(QRect(570, 170, 211, 161));
        frame_6->setStyleSheet(QString::fromUtf8("background-color: rgb(163, 163, 163);"));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        aa = new QPushButton(frame_5);
        aa->setObjectName(QString::fromUtf8("aa"));
        aa->setGeometry(QRect(500, 650, 206, 40));
        aa->setMaximumSize(QSize(16777215, 16777213));
        aa->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_aa{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_aa{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon18;
        icon18.addFile(QString::fromUtf8(":/img/img/check-circle.svg"), QSize(), QIcon::Normal, QIcon::Off);
        aa->setIcon(icon18);
        p9_3 = new QPushButton(frame_5);
        p9_3->setObjectName(QString::fromUtf8("p9_3"));
        p9_3->setGeometry(QRect(760, 650, 161, 41));
        p9_3->setMaximumSize(QSize(16777215, 16777213));
        p9_3->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_bb{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_bb{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_bb:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_bb:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon19;
        icon19.addFile(QString::fromUtf8(":/img/img/plus-circle.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p9_3->setIcon(icon19);
        label_26 = new QLabel(frame_5);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(350, 20, 271, 41));
        QFont font5;
        font5.setFamilies({QString::fromUtf8("Bell MT")});
        font5.setPointSize(20);
        font5.setBold(false);
        label_26->setFont(font5);
        label_26->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_30 = new QPushButton(frame_5);
        pushButton_30->setObjectName(QString::fromUtf8("pushButton_30"));
        pushButton_30->setGeometry(QRect(790, 170, 51, 41));
        pushButton_30->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_20{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_20{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_20:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_20:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon20;
        icon20.addFile(QString::fromUtf8(":/img/img/upload.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_30->setIcon(icon20);
        pushButton_30->setCheckable(true);
        pushButton_30->setAutoExclusive(true);
        lineEdit_15 = new QLineEdit(frame_5);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(190, 290, 113, 28));
        lineEdit_15->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        comboBox_2 = new QComboBox(frame_5);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(191, 420, 101, 28));
        comboBox_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        label_149 = new QLabel(frame_5);
        label_149->setObjectName(QString::fromUtf8("label_149"));
        label_149->setGeometry(QRect(40, 470, 131, 31));
        label_149->setFont(font4);
        label_149->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        dateEdit_11 = new QDateEdit(frame_5);
        dateEdit_11->setObjectName(QString::fromUtf8("dateEdit_11"));
        dateEdit_11->setGeometry(QRect(200, 470, 110, 29));
        dateEdit_11->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        stackedWidget->addWidget(a3);
        a3_1 = new QWidget();
        a3_1->setObjectName(QString::fromUtf8("a3_1"));
        frame_10 = new QFrame(a3_1);
        frame_10->setObjectName(QString::fromUtf8("frame_10"));
        frame_10->setGeometry(QRect(60, 80, 981, 721));
        frame_10->setStyleSheet(QString::fromUtf8("\n"
"\n"
"background-color: rgb(202, 255, 251);\n"
"border-radius:20px;"));
        frame_10->setFrameShape(QFrame::StyledPanel);
        frame_10->setFrameShadow(QFrame::Raised);
        aa_2 = new QPushButton(frame_10);
        aa_2->setObjectName(QString::fromUtf8("aa_2"));
        aa_2->setGeometry(QRect(70, 560, 206, 40));
        aa_2->setMaximumSize(QSize(16777215, 16777213));
        aa_2->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_aa{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_aa{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        aa_2->setIcon(icon18);
        p9_4 = new QPushButton(frame_10);
        p9_4->setObjectName(QString::fromUtf8("p9_4"));
        p9_4->setGeometry(QRect(290, 560, 191, 41));
        p9_4->setMaximumSize(QSize(16777215, 16777213));
        p9_4->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_bb{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_bb{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_bb:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_bb:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon21;
        icon21.addFile(QString::fromUtf8(":/img/img/save.svg"), QSize(), QIcon::Normal, QIcon::Off);
        p9_4->setIcon(icon21);
        lineEdit = new QLineEdit(frame_10);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(112, 77, 171, 31));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        aa_3 = new QPushButton(frame_10);
        aa_3->setObjectName(QString::fromUtf8("aa_3"));
        aa_3->setGeometry(QRect(300, 70, 61, 41));
        aa_3->setMaximumSize(QSize(16777215, 16777213));
        aa_3->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_aa{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_aa{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        aa_3->setIcon(icon18);
        aa_4 = new QPushButton(frame_10);
        aa_4->setObjectName(QString::fromUtf8("aa_4"));
        aa_4->setGeometry(QRect(668, 73, 61, 41));
        aa_4->setMaximumSize(QSize(16777215, 16777213));
        aa_4->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_aa{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_aa{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        QIcon icon22;
        icon22.addFile(QString::fromUtf8(":/img/img/filter.svg"), QSize(), QIcon::Normal, QIcon::Off);
        aa_4->setIcon(icon22);
        label_27 = new QLabel(frame_10);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(380, 79, 81, 31));
        QFont font6;
        font6.setPointSize(11);
        font6.setBold(true);
        label_27->setFont(font6);
        label_27->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboBox_4 = new QComboBox(frame_10);
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));
        comboBox_4->setGeometry(QRect(520, 80, 131, 31));
        comboBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        tableWidget_2 = new QTableWidget(frame_10);
        if (tableWidget_2->columnCount() < 7)
            tableWidget_2->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(1, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(2, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(3, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(4, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(5, __qtablewidgetitem33);
        QTableWidgetItem *__qtablewidgetitem34 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(6, __qtablewidgetitem34);
        if (tableWidget_2->rowCount() < 2)
            tableWidget_2->setRowCount(2);
        QTableWidgetItem *__qtablewidgetitem35 = new QTableWidgetItem();
        __qtablewidgetitem35->setIcon(icon14);
        tableWidget_2->setVerticalHeaderItem(0, __qtablewidgetitem35);
        QTableWidgetItem *__qtablewidgetitem36 = new QTableWidgetItem();
        __qtablewidgetitem36->setIcon(icon14);
        tableWidget_2->setVerticalHeaderItem(1, __qtablewidgetitem36);
        QTableWidgetItem *__qtablewidgetitem37 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 0, __qtablewidgetitem37);
        QTableWidgetItem *__qtablewidgetitem38 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 1, __qtablewidgetitem38);
        QTableWidgetItem *__qtablewidgetitem39 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 2, __qtablewidgetitem39);
        QTableWidgetItem *__qtablewidgetitem40 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 4, __qtablewidgetitem40);
        QTableWidgetItem *__qtablewidgetitem41 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 0, __qtablewidgetitem41);
        QTableWidgetItem *__qtablewidgetitem42 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 1, __qtablewidgetitem42);
        QTableWidgetItem *__qtablewidgetitem43 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 2, __qtablewidgetitem43);
        tableWidget_2->setObjectName(QString::fromUtf8("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(30, 160, 941, 371));
        tableWidget_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        aa_5 = new QPushButton(frame_10);
        aa_5->setObjectName(QString::fromUtf8("aa_5"));
        aa_5->setGeometry(QRect(760, 590, 161, 41));
        aa_5->setMaximumSize(QSize(16777215, 16777213));
        aa_5->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_aa{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_aa{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_aa:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        aa_5->setIcon(icon18);
        p9_5 = new QPushButton(frame_10);
        p9_5->setObjectName(QString::fromUtf8("p9_5"));
        p9_5->setGeometry(QRect(765, 641, 161, 41));
        p9_5->setMaximumSize(QSize(16777215, 16777213));
        p9_5->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_bb{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_bb{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_bb:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_bb:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        p9_5->setIcon(icon19);
        stackedWidget->addWidget(a3_1);
        a2 = new QWidget();
        a2->setObjectName(QString::fromUtf8("a2"));
        frame_14 = new QFrame(a2);
        frame_14->setObjectName(QString::fromUtf8("frame_14"));
        frame_14->setGeometry(QRect(10, 150, 391, 621));
        frame_14->setFrameShape(QFrame::StyledPanel);
        frame_14->setFrameShadow(QFrame::Raised);
        frame_15 = new QFrame(frame_14);
        frame_15->setObjectName(QString::fromUtf8("frame_15"));
        frame_15->setGeometry(QRect(20, 40, 351, 571));
        frame_15->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251);\n"
"border-radius:15px;\n"
""));
        frame_15->setFrameShape(QFrame::StyledPanel);
        frame_15->setFrameShadow(QFrame::Raised);
        add_2 = new QPushButton(frame_15);
        add_2->setObjectName(QString::fromUtf8("add_2"));
        add_2->setGeometry(QRect(250, 510, 83, 41));
        add_2->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        add_2->setCheckable(true);
        label_29 = new QLabel(frame_15);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(100, 80, 101, 21));
        label_29->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_33 = new QLabel(frame_15);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setGeometry(QRect(120, 149, 91, 21));
        label_33->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_36 = new QLabel(frame_15);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setGeometry(QRect(100, 210, 121, 21));
        label_36->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_37 = new QLabel(frame_15);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(100, 279, 91, 21));
        label_37->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_23 = new QPushButton(frame_15);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setGeometry(QRect(150, 500, 61, 51));
        pushButton_23->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_20{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_20{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_20:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_20:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_23->setIcon(icon9);
        lineEdit_24 = new QLineEdit(frame_15);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));
        lineEdit_24->setGeometry(QRect(100, 100, 161, 28));
        lineEdit_24->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_25 = new QLineEdit(frame_15);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));
        lineEdit_25->setGeometry(QRect(100, 230, 161, 28));
        lineEdit_25->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        lineEdit_26 = new QLineEdit(frame_15);
        lineEdit_26->setObjectName(QString::fromUtf8("lineEdit_26"));
        lineEdit_26->setGeometry(QRect(100, 300, 161, 28));
        lineEdit_26->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);"));
        dateEdit_4 = new QDateEdit(frame_15);
        dateEdit_4->setObjectName(QString::fromUtf8("dateEdit_4"));
        dateEdit_4->setGeometry(QRect(100, 380, 161, 29));
        dateEdit_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));
        label_38 = new QLabel(frame_15);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setGeometry(QRect(100, 360, 141, 21));
        label_38->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        radioButton_2 = new QRadioButton(frame_15);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(40, 180, 112, 26));
        radioButton_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        radioButton_4 = new QRadioButton(frame_15);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));
        radioButton_4->setGeometry(QRect(200, 180, 112, 26));
        radioButton_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_24 = new QLabel(frame_15);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(80, 10, 201, 61));
        label_24->setFont(font6);
        label_24->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(160, 255, 228);"));
        add_5 = new QPushButton(frame_15);
        add_5->setObjectName(QString::fromUtf8("add_5"));
        add_5->setGeometry(QRect(30, 510, 83, 41));
        add_5->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        add_5->setCheckable(true);
        frame_16 = new QFrame(a2);
        frame_16->setObjectName(QString::fromUtf8("frame_16"));
        frame_16->setGeometry(QRect(410, 170, 791, 591));
        frame_16->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(202, 255, 251);\n"
"border-radius:15px;\n"
""));
        frame_16->setFrameShape(QFrame::StyledPanel);
        frame_16->setFrameShadow(QFrame::Raised);
        label_32 = new QLabel(frame_16);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setGeometry(QRect(440, 30, 131, 31));
        label_32->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_31 = new QLabel(frame_16);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(10, 29, 151, 31));
        label_31->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboBox_5 = new QComboBox(frame_16);
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));
        comboBox_5->setGeometry(QRect(540, 30, 121, 28));
        comboBox_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        tableWidget_4 = new QTableWidget(frame_16);
        if (tableWidget_4->columnCount() < 5)
            tableWidget_4->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem44 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(0, __qtablewidgetitem44);
        QTableWidgetItem *__qtablewidgetitem45 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(1, __qtablewidgetitem45);
        QTableWidgetItem *__qtablewidgetitem46 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(2, __qtablewidgetitem46);
        QTableWidgetItem *__qtablewidgetitem47 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(3, __qtablewidgetitem47);
        QTableWidgetItem *__qtablewidgetitem48 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(4, __qtablewidgetitem48);
        if (tableWidget_4->rowCount() < 5)
            tableWidget_4->setRowCount(5);
        QTableWidgetItem *__qtablewidgetitem49 = new QTableWidgetItem();
        tableWidget_4->setVerticalHeaderItem(0, __qtablewidgetitem49);
        QTableWidgetItem *__qtablewidgetitem50 = new QTableWidgetItem();
        tableWidget_4->setVerticalHeaderItem(1, __qtablewidgetitem50);
        QTableWidgetItem *__qtablewidgetitem51 = new QTableWidgetItem();
        tableWidget_4->setVerticalHeaderItem(2, __qtablewidgetitem51);
        QTableWidgetItem *__qtablewidgetitem52 = new QTableWidgetItem();
        tableWidget_4->setVerticalHeaderItem(3, __qtablewidgetitem52);
        QTableWidgetItem *__qtablewidgetitem53 = new QTableWidgetItem();
        tableWidget_4->setVerticalHeaderItem(4, __qtablewidgetitem53);
        tableWidget_4->setObjectName(QString::fromUtf8("tableWidget_4"));
        tableWidget_4->setGeometry(QRect(10, 70, 771, 321));
        tableWidget_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_5 = new QPushButton(frame_16);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(322, 18, 71, 41));
        pushButton_5->setStyleSheet(QString::fromUtf8("QPushButton, #pushButton_4 {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"    color: rgba(255, 255, 255, 210);\n"
"    border-radius: 5px;\n"
"    transition: background-color 0.3s ease-in-out; /* Transition effect */\n"
"}\n"
"\n"
"QPushButton#pushButton_4:hover {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, \n"
"        stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_4:pressed {\n"
"    padding-left: 5px;\n"
"    padding-top: 5px;\n"
"    background-color: rgba(150, 123, 111, 255);\n"
"    transition: background-color 0.1s ease-out; /* Faster transition when pressed */\n"
"}\n"
"\n"
"\n"
"\n"
"color: rgb(0, 0, 0);"));
        edit_4 = new QLineEdit(frame_16);
        edit_4->setObjectName(QString::fromUtf8("edit_4"));
        edit_4->setGeometry(QRect(160, 30, 141, 31));
        edit_4->setMinimumSize(QSize(0, 31));
        edit_4->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        edit_7 = new QLineEdit(frame_16);
        edit_7->setObjectName(QString::fromUtf8("edit_7"));
        edit_7->setGeometry(QRect(370, 520, 141, 31));
        edit_7->setMinimumSize(QSize(0, 31));
        edit_7->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	padding-left: 20px;\n"
"	border: 1px solid gray;	\n"
"	border-radius: 10px;\n"
"color: rgb(0, 0, 0);\n"
"\n"
"}\n"
""));
        label_49 = new QLabel(frame_16);
        label_49->setObjectName(QString::fromUtf8("label_49"));
        label_49->setGeometry(QRect(220, 510, 31, 41));
        label_49->setPixmap(QPixmap(QString::fromUtf8(":/img/img/download.svg")));
        pushButton_31 = new QPushButton(frame_16);
        pushButton_31->setObjectName(QString::fromUtf8("pushButton_31"));
        pushButton_31->setGeometry(QRect(520, 500, 151, 61));
        pushButton_31->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_21{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_21:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_21:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pushButton_33 = new QPushButton(frame_16);
        pushButton_33->setObjectName(QString::fromUtf8("pushButton_33"));
        pushButton_33->setGeometry(QRect(60, 500, 141, 61));
        pushButton_33->setStyleSheet(QString::fromUtf8("\n"
"#pushButton_21{\n"
"color: rgb(0, 0, 0);\n"
"}\n"
"QPushButton, #pushButton_29{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));\n"
"	color:rgba(255, 255, 255, 210);\n"
"	border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_29:hover{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_29:pressed{\n"
"	padding-left:5px;\n"
"	padding-top:5px;\n"
"	background-color:rgba(150, 123, 111, 255);\n"
"}\n"
""));
        pic1_4 = new QLabel(a2);
        pic1_4->setObjectName(QString::fromUtf8("pic1_4"));
        pic1_4->setGeometry(QRect(180, 10, 591, 151));
        pic1_4->setPixmap(QPixmap(QString::fromUtf8("img/Nouveau dossier/aze.png")));
        stackedWidget->addWidget(a2);

        horizontalLayout_3->addWidget(stackedWidget);


        verticalLayout_15->addWidget(main_screen_widget);


        gridLayout->addLayout(verticalLayout_15, 0, 2, 1, 1);

        icon_names_text_widget = new QWidget(layoutWidget);
        icon_names_text_widget->setObjectName(QString::fromUtf8("icon_names_text_widget"));
        verticalLayout_16 = new QVBoxLayout(icon_names_text_widget);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        p9 = new QPushButton(icon_names_text_widget);
        p9->setObjectName(QString::fromUtf8("p9"));
        p9->setMaximumSize(QSize(16777215, 16777213));
        p9->setIcon(icon);

        verticalLayout_16->addWidget(p9);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        RH = new QFrame(icon_names_text_widget);
        RH->setObjectName(QString::fromUtf8("RH"));
        RH->setFrameShape(QFrame::StyledPanel);
        RH->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(RH);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        p14 = new QPushButton(RH);
        p14->setObjectName(QString::fromUtf8("p14"));
        p14->setIcon(icon1);
        p14->setCheckable(true);

        verticalLayout_5->addWidget(p14);

        frame_rh = new QFrame(RH);
        frame_rh->setObjectName(QString::fromUtf8("frame_rh"));
        frame_rh->setFrameShape(QFrame::StyledPanel);
        frame_rh->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame_rh);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton_8 = new QPushButton(frame_rh);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setCheckable(true);

        verticalLayout->addWidget(pushButton_8);

        pushButton_10 = new QPushButton(frame_rh);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setCheckable(true);

        verticalLayout->addWidget(pushButton_10);


        verticalLayout_5->addWidget(frame_rh);


        verticalLayout_9->addWidget(RH);

        SL = new QFrame(icon_names_text_widget);
        SL->setObjectName(QString::fromUtf8("SL"));
        SL->setFrameShape(QFrame::StyledPanel);
        SL->setFrameShadow(QFrame::Raised);
        verticalLayout_6 = new QVBoxLayout(SL);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        p11 = new QPushButton(SL);
        p11->setObjectName(QString::fromUtf8("p11"));
        p11->setIcon(icon2);
        p11->setCheckable(true);

        verticalLayout_6->addWidget(p11);

        frame_sales = new QFrame(SL);
        frame_sales->setObjectName(QString::fromUtf8("frame_sales"));
        frame_sales->setFrameShape(QFrame::StyledPanel);
        frame_sales->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(frame_sales);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        pushButton_12 = new QPushButton(frame_sales);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_12);

        pushButton_14 = new QPushButton(frame_sales);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setCheckable(true);

        verticalLayout_2->addWidget(pushButton_14);


        verticalLayout_6->addWidget(frame_sales);


        verticalLayout_9->addWidget(SL);

        frame_9 = new QFrame(icon_names_text_widget);
        frame_9->setObjectName(QString::fromUtf8("frame_9"));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Raised);
        verticalLayout_10 = new QVBoxLayout(frame_9);
        verticalLayout_10->setSpacing(0);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        pushButton_6 = new QPushButton(frame_9);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setIcon(icon3);
        pushButton_6->setCheckable(true);

        verticalLayout_10->addWidget(pushButton_6);

        frame_ord_2 = new QFrame(frame_9);
        frame_ord_2->setObjectName(QString::fromUtf8("frame_ord_2"));
        frame_ord_2->setFrameShape(QFrame::StyledPanel);
        frame_ord_2->setFrameShadow(QFrame::Raised);
        verticalLayout_11 = new QVBoxLayout(frame_ord_2);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        pushButton_35 = new QPushButton(frame_ord_2);
        pushButton_35->setObjectName(QString::fromUtf8("pushButton_35"));
        pushButton_35->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_35);

        pushButton_36 = new QPushButton(frame_ord_2);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_36);

        pushButton_37 = new QPushButton(frame_ord_2);
        pushButton_37->setObjectName(QString::fromUtf8("pushButton_37"));
        pushButton_37->setCheckable(true);

        verticalLayout_11->addWidget(pushButton_37);


        verticalLayout_10->addWidget(frame_ord_2);


        verticalLayout_9->addWidget(frame_9);

        SK = new QFrame(icon_names_text_widget);
        SK->setObjectName(QString::fromUtf8("SK"));
        SK->setFrameShape(QFrame::StyledPanel);
        SK->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(SK);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        p13 = new QPushButton(SK);
        p13->setObjectName(QString::fromUtf8("p13"));
        p13->setIcon(icon4);
        p13->setIconSize(QSize(50, 20));
        p13->setCheckable(true);

        verticalLayout_7->addWidget(p13);

        frame_stc = new QFrame(SK);
        frame_stc->setObjectName(QString::fromUtf8("frame_stc"));
        frame_stc->setFrameShape(QFrame::StyledPanel);
        frame_stc->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_stc);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        pushButton_25 = new QPushButton(frame_stc);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_25);

        pushButton_24 = new QPushButton(frame_stc);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setCheckable(true);

        verticalLayout_3->addWidget(pushButton_24);


        verticalLayout_7->addWidget(frame_stc);


        verticalLayout_9->addWidget(SK);

        frame_8 = new QFrame(icon_names_text_widget);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Raised);
        verticalLayout_8 = new QVBoxLayout(frame_8);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        p10 = new QPushButton(frame_8);
        p10->setObjectName(QString::fromUtf8("p10"));
        p10->setIcon(icon5);
        p10->setCheckable(true);

        verticalLayout_8->addWidget(p10);

        frame_ord = new QFrame(frame_8);
        frame_ord->setObjectName(QString::fromUtf8("frame_ord"));
        frame_ord->setFrameShape(QFrame::StyledPanel);
        frame_ord->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(frame_ord);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        pushButton_27 = new QPushButton(frame_ord);
        pushButton_27->setObjectName(QString::fromUtf8("pushButton_27"));
        pushButton_27->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_27);

        pushButton_28 = new QPushButton(frame_ord);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setCheckable(true);

        verticalLayout_4->addWidget(pushButton_28);


        verticalLayout_8->addWidget(frame_ord);


        verticalLayout_9->addWidget(frame_8);


        verticalLayout_16->addLayout(verticalLayout_9);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_12->addItem(verticalSpacer);

        p15 = new QPushButton(icon_names_text_widget);
        p15->setObjectName(QString::fromUtf8("p15"));
        p15->setIcon(icon6);
        p15->setCheckable(true);
        p15->setAutoExclusive(false);

        verticalLayout_12->addWidget(p15);

        p16 = new QPushButton(icon_names_text_widget);
        p16->setObjectName(QString::fromUtf8("p16"));
        p16->setIcon(icon7);
        p16->setCheckable(true);
        p16->setAutoExclusive(false);

        verticalLayout_12->addWidget(p16);


        verticalLayout_16->addLayout(verticalLayout_12);


        gridLayout->addWidget(icon_names_text_widget, 0, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(p16, &QPushButton::toggled, pushButton_16, &QPushButton::setChecked);
        QObject::connect(pushButton_23, &QPushButton::clicked, lineEdit_26, qOverload<>(&QLineEdit::clear));
        QObject::connect(p14, &QPushButton::toggled, p20, &QPushButton::setChecked);
        QObject::connect(p13, &QPushButton::toggled, p23, &QPushButton::setChecked);
        QObject::connect(pushButton_16, &QPushButton::toggled, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(p10, &QPushButton::toggled, frame_ord, &QFrame::setHidden);
        QObject::connect(p17, &QPushButton::toggled, icon_only_widget, &QWidget::setVisible);
        QObject::connect(pushButton_20, &QPushButton::clicked, lineEdit_16, qOverload<>(&QLineEdit::clear));
        QObject::connect(p13, &QPushButton::toggled, frame_stc, &QFrame::setHidden);
        QObject::connect(p20, &QPushButton::toggled, p14, &QPushButton::setChecked);
        QObject::connect(p11, &QPushButton::toggled, frame_sales, &QFrame::setHidden);
        QObject::connect(p15, &QPushButton::toggled, pushButton_15, &QPushButton::setChecked);
        QObject::connect(p9, &QPushButton::toggled, pushButton, &QPushButton::setChecked);
        QObject::connect(p11, &QPushButton::toggled, p21, &QPushButton::setChecked);
        QObject::connect(pushButton_20, &QPushButton::clicked, lineEdit_17, qOverload<>(&QLineEdit::clear));
        QObject::connect(p14, &QPushButton::toggled, frame_rh, &QFrame::setHidden);
        QObject::connect(pushButton_6, &QPushButton::toggled, frame_ord_2, &QFrame::setHidden);
        QObject::connect(pushButton_23, &QPushButton::clicked, lineEdit_24, qOverload<>(&QLineEdit::clear));
        QObject::connect(p16, &QPushButton::toggled, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(pushButton_22, &QPushButton::clicked, lineEdit_13, qOverload<>(&QLineEdit::clear));
        QObject::connect(pushButton_23, &QPushButton::clicked, lineEdit_25, qOverload<>(&QLineEdit::clear));
        QObject::connect(pushButton_6, &QPushButton::toggled, p22, &QPushButton::setChecked);
        QObject::connect(p10, &QPushButton::toggled, p24, &QPushButton::setChecked);
        QObject::connect(p17, &QPushButton::toggled, icon_names_text_widget, &QWidget::setHidden);

        stackedWidget->setCurrentIndex(9);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QString());
        p20->setText(QString());
        p21->setText(QString());
        p22->setText(QString());
        p23->setText(QString());
        p24->setText(QString());
        pushButton_15->setText(QString());
        pushButton_16->setText(QString());
        p17->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Hello", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Welcome to your page", nullptr));
        edit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Search here ...", nullptr));
        label_4->setText(QString());
        label_35->setText(QString());
        label_75->setText(QCoreApplication::translate("MainWindow", "Statistic :", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Modify", nullptr));
        add->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        pushButton_20->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "Log in", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "First name", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "Phone number", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Salary", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Password", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "CIN", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Last name", nullptr));
        label_46->setText(QCoreApplication::translate("MainWindow", "Role", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("MainWindow", "Admin", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("MainWindow", "sales section", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("MainWindow", "order section", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("MainWindow", "commande section", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("MainWindow", "stock section", nullptr));

        label_8->setText(QCoreApplication::translate("MainWindow", "Gender", nullptr));
        radioButton->setText(QCoreApplication::translate("MainWindow", "Male", nullptr));
        radioButton_3->setText(QCoreApplication::translate("MainWindow", "Female", nullptr));
        label_44->setText(QCoreApplication::translate("MainWindow", "Date of Birth", nullptr));
        label_45->setText(QCoreApplication::translate("MainWindow", "Hire Date", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "Add or Update Employer", nullptr));
        pic1->setText(QString());
        label_15->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        edit_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        comboBox_3->setItemText(0, QCoreApplication::translate("MainWindow", "Salary", nullptr));
        comboBox_3->setItemText(1, QCoreApplication::translate("MainWindow", "Age", nullptr));
        comboBox_3->setItemText(2, QCoreApplication::translate("MainWindow", "Date of hire", nullptr));

        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "id", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "cin", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "Adress", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", " Number", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "Date of hire", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "Role", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "client1", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "client2", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("MainWindow", "client3", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("MainWindow", "client4", nullptr));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->verticalHeaderItem(4);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("MainWindow", "client5", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->verticalHeaderItem(5);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("MainWindow", "client6", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        tableWidget->setSortingEnabled(__sortingEnabled);

        pushButton_29->setText(QCoreApplication::translate("MainWindow", "Exporting PDF", nullptr));
        label_42->setText(QString());
        edit_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        pushButton_21->setText(QCoreApplication::translate("MainWindow", "Delete Employer", nullptr));
        label_34->setText(QString());
        label_73->setText(QCoreApplication::translate("MainWindow", "Statistic :", nullptr));
        comboBox_6->setItemText(0, QCoreApplication::translate("MainWindow", "Pending", nullptr));
        comboBox_6->setItemText(1, QCoreApplication::translate("MainWindow", "Confirmed", nullptr));
        comboBox_6->setItemText(2, QCoreApplication::translate("MainWindow", "Shipped", nullptr));
        comboBox_6->setItemText(3, QCoreApplication::translate("MainWindow", "Canceled", nullptr));

        comboBox_8->setItemText(0, QCoreApplication::translate("MainWindow", "date", nullptr));

        edit_8->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_5->horizontalHeaderItem(0);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_5->horizontalHeaderItem(1);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("MainWindow", "PRICE", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_5->horizontalHeaderItem(2);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("MainWindow", "FIRST NAME", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_5->horizontalHeaderItem(3);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("MainWindow", "LAST NAME", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_5->horizontalHeaderItem(4);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("MainWindow", "QUANTITY", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget_5->verticalHeaderItem(0);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("MainWindow", "client1", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget_5->verticalHeaderItem(1);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("MainWindow", "client2", nullptr));

        const bool __sortingEnabled1 = tableWidget_5->isSortingEnabled();
        tableWidget_5->setSortingEnabled(false);
        tableWidget_5->setSortingEnabled(__sortingEnabled1);

        label_39->setText(QCoreApplication::translate("MainWindow", " Delete order:", nullptr));
        pushButton_39->setText(QCoreApplication::translate("MainWindow", " Statistics", nullptr));
        label_47->setText(QCoreApplication::translate("MainWindow", "Order Status", nullptr));
        edit_9->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        label_48->setText(QCoreApplication::translate("MainWindow", "Sort", nullptr));
        pushButton_26->setText(QCoreApplication::translate("MainWindow", " Exporting PDF", nullptr));
        label_51->setText(QString());
        label_54->setText(QCoreApplication::translate("MainWindow", "PRICE", nullptr));
        label_55->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        label_57->setText(QCoreApplication::translate("MainWindow", "Last name", nullptr));
        label_58->setText(QCoreApplication::translate("MainWindow", "First name", nullptr));
        label_59->setText(QCoreApplication::translate("MainWindow", "QUANTITY", nullptr));
        label_60->setText(QCoreApplication::translate("MainWindow", "Date", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "Update an order", nullptr));
        toolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "CANCEL", nullptr));
        label_52->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        label_72->setText(QCoreApplication::translate("MainWindow", "           Add Order", nullptr));
        label_61->setText(QCoreApplication::translate("MainWindow", "wissal", nullptr));
        label_70->setText(QCoreApplication::translate("MainWindow", "Statistic :", nullptr));
        label_64->setText(QString());
        label_71->setText(QString());
        label_30->setText(QString());
        pic1_3->setText(QString());
        label_69->setText(QCoreApplication::translate("MainWindow", "Welcome to Our Desktop", nullptr));
        add_3->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_40->setText(QCoreApplication::translate("MainWindow", "Name of Cure", nullptr));
        label_41->setText(QCoreApplication::translate("MainWindow", "Number Id", nullptr));
        label_43->setText(QCoreApplication::translate("MainWindow", "Expiration Date", nullptr));
        label_50->setText(QCoreApplication::translate("MainWindow", "type cure", nullptr));
        label_53->setText(QCoreApplication::translate("MainWindow", "Quantity", nullptr));
        pushButton_32->setText(QString());
        label_68->setText(QCoreApplication::translate("MainWindow", "     Add Cure", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget_3->horizontalHeaderItem(0);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("MainWindow", "Nom Produit", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget_3->horizontalHeaderItem(1);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("MainWindow", "Type ", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget_3->horizontalHeaderItem(2);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("MainWindow", "Quantity", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget_3->horizontalHeaderItem(3);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("MainWindow", "Family cure", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget_3->horizontalHeaderItem(4);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("MainWindow", "Expirement Date", nullptr));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget_3->verticalHeaderItem(0);
        ___qtablewidgetitem24->setText(QCoreApplication::translate("MainWindow", "Product", nullptr));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget_3->verticalHeaderItem(1);
        ___qtablewidgetitem25->setText(QCoreApplication::translate("MainWindow", "Product", nullptr));
        pic1_2->setText(QString());
        pushButton_34->setText(QCoreApplication::translate("MainWindow", "Delete cure", nullptr));
        edit_6->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        label_65->setText(QString());
        pushButton_38->setText(QCoreApplication::translate("MainWindow", "Exporting PDF", nullptr));
        comboBox_7->setItemText(0, QCoreApplication::translate("MainWindow", "Cure name", nullptr));
        comboBox_7->setItemText(1, QCoreApplication::translate("MainWindow", "Family", nullptr));
        comboBox_7->setItemText(2, QCoreApplication::translate("MainWindow", "Cure Code", nullptr));
        comboBox_7->setItemText(3, QString());

        label_66->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        edit_3->setText(QCoreApplication::translate("MainWindow", "Search for Stock", nullptr));
        edit_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        label_67->setText(QCoreApplication::translate("MainWindow", "Search for Employe:", nullptr));
        pushButton_13->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        label_56->setText(QString());
        label_62->setText(QString());
        label_74->setText(QCoreApplication::translate("MainWindow", "Statistic :", nullptr));
        pushButton_22->setText(QString());
        label_16->setText(QCoreApplication::translate("MainWindow", "CIN:", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "First Name:", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "Last Name:", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "Phone Number", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "Status ", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "Medecine :", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "Order Number:", nullptr));
        lineEdit_8->setText(QString());
        label_23->setText(QCoreApplication::translate("MainWindow", "Prescription :", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "Upload Prescription:", nullptr));
        aa->setText(QCoreApplication::translate("MainWindow", "Confirm update", nullptr));
        p9_3->setText(QCoreApplication::translate("MainWindow", "Confirm ADD", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "Prescription Form", nullptr));
        pushButton_30->setText(QString());
        comboBox_2->setItemText(0, QCoreApplication::translate("MainWindow", "Pending", nullptr));
        comboBox_2->setItemText(1, QCoreApplication::translate("MainWindow", "Expired", nullptr));
        comboBox_2->setItemText(2, QCoreApplication::translate("MainWindow", "Filled", nullptr));

        label_149->setText(QCoreApplication::translate("MainWindow", "Date", nullptr));
        aa_2->setText(QCoreApplication::translate("MainWindow", "Upload PDF", nullptr));
        p9_4->setText(QCoreApplication::translate("MainWindow", "Appoiment History", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Search...", nullptr));
        aa_3->setText(QString());
        aa_4->setText(QString());
        label_27->setText(QCoreApplication::translate("MainWindow", "Sort by", nullptr));
        comboBox_4->setItemText(0, QCoreApplication::translate("MainWindow", "STATUS", nullptr));
        comboBox_4->setItemText(1, QCoreApplication::translate("MainWindow", "Medecine", nullptr));
        comboBox_4->setItemText(2, QCoreApplication::translate("MainWindow", "Prescripton date", nullptr));

        QTableWidgetItem *___qtablewidgetitem26 = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem26->setText(QCoreApplication::translate("MainWindow", "Appointment Id", nullptr));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget_2->horizontalHeaderItem(1);
        ___qtablewidgetitem27->setText(QCoreApplication::translate("MainWindow", "AppDate", nullptr));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget_2->horizontalHeaderItem(2);
        ___qtablewidgetitem28->setText(QCoreApplication::translate("MainWindow", "AppTime", nullptr));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidget_2->horizontalHeaderItem(3);
        ___qtablewidgetitem29->setText(QCoreApplication::translate("MainWindow", "AppType", nullptr));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidget_2->horizontalHeaderItem(4);
        ___qtablewidgetitem30->setText(QCoreApplication::translate("MainWindow", "AppStatus", nullptr));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidget_2->horizontalHeaderItem(5);
        ___qtablewidgetitem31->setText(QCoreApplication::translate("MainWindow", "DoctorID", nullptr));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidget_2->horizontalHeaderItem(6);
        ___qtablewidgetitem32->setText(QCoreApplication::translate("MainWindow", "Patient ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidget_2->verticalHeaderItem(0);
        ___qtablewidgetitem33->setText(QCoreApplication::translate("MainWindow", "client1", nullptr));
        QTableWidgetItem *___qtablewidgetitem34 = tableWidget_2->verticalHeaderItem(1);
        ___qtablewidgetitem34->setText(QCoreApplication::translate("MainWindow", "client2", nullptr));

        const bool __sortingEnabled2 = tableWidget_2->isSortingEnabled();
        tableWidget_2->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem35 = tableWidget_2->item(0, 0);
        ___qtablewidgetitem35->setText(QCoreApplication::translate("MainWindow", "141", nullptr));
        QTableWidgetItem *___qtablewidgetitem36 = tableWidget_2->item(0, 1);
        ___qtablewidgetitem36->setText(QCoreApplication::translate("MainWindow", "13-10-2024", nullptr));
        QTableWidgetItem *___qtablewidgetitem37 = tableWidget_2->item(0, 2);
        ___qtablewidgetitem37->setText(QCoreApplication::translate("MainWindow", "Cures manager", nullptr));
        QTableWidgetItem *___qtablewidgetitem38 = tableWidget_2->item(1, 0);
        ___qtablewidgetitem38->setText(QCoreApplication::translate("MainWindow", "142", nullptr));
        QTableWidgetItem *___qtablewidgetitem39 = tableWidget_2->item(1, 1);
        ___qtablewidgetitem39->setText(QCoreApplication::translate("MainWindow", "13-10-2024", nullptr));
        tableWidget_2->setSortingEnabled(__sortingEnabled2);

        aa_5->setText(QCoreApplication::translate("MainWindow", "Confirm update", nullptr));
        p9_5->setText(QCoreApplication::translate("MainWindow", "Confirm ADD", nullptr));
        add_2->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "Total Amount:", nullptr));
        label_33->setText(QCoreApplication::translate("MainWindow", "Type:", nullptr));
        label_36->setText(QCoreApplication::translate("MainWindow", "Payment method:", nullptr));
        label_37->setText(QCoreApplication::translate("MainWindow", "Category:", nullptr));
        pushButton_23->setText(QString());
        label_38->setText(QCoreApplication::translate("MainWindow", "Date of Transaction:", nullptr));
        radioButton_2->setText(QCoreApplication::translate("MainWindow", "Income", nullptr));
        radioButton_4->setText(QCoreApplication::translate("MainWindow", "Expense", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "      Add Transaction ", nullptr));
        add_5->setText(QCoreApplication::translate("MainWindow", "Modify", nullptr));
        label_32->setText(QCoreApplication::translate("MainWindow", "Sort by", nullptr));
        label_31->setText(QCoreApplication::translate("MainWindow", "Search for transaction", nullptr));
        comboBox_5->setItemText(0, QCoreApplication::translate("MainWindow", "Total Amount", nullptr));
        comboBox_5->setItemText(1, QCoreApplication::translate("MainWindow", "Date of transaction", nullptr));
        comboBox_5->setItemText(2, QCoreApplication::translate("MainWindow", "Type", nullptr));

        QTableWidgetItem *___qtablewidgetitem40 = tableWidget_4->horizontalHeaderItem(0);
        ___qtablewidgetitem40->setText(QCoreApplication::translate("MainWindow", "Total Amount", nullptr));
        QTableWidgetItem *___qtablewidgetitem41 = tableWidget_4->horizontalHeaderItem(1);
        ___qtablewidgetitem41->setText(QCoreApplication::translate("MainWindow", "Type", nullptr));
        QTableWidgetItem *___qtablewidgetitem42 = tableWidget_4->horizontalHeaderItem(2);
        ___qtablewidgetitem42->setText(QCoreApplication::translate("MainWindow", "Payment method", nullptr));
        QTableWidgetItem *___qtablewidgetitem43 = tableWidget_4->horizontalHeaderItem(3);
        ___qtablewidgetitem43->setText(QCoreApplication::translate("MainWindow", "Date", nullptr));
        QTableWidgetItem *___qtablewidgetitem44 = tableWidget_4->horizontalHeaderItem(4);
        ___qtablewidgetitem44->setText(QCoreApplication::translate("MainWindow", "Category", nullptr));
        QTableWidgetItem *___qtablewidgetitem45 = tableWidget_4->verticalHeaderItem(0);
        ___qtablewidgetitem45->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem46 = tableWidget_4->verticalHeaderItem(1);
        ___qtablewidgetitem46->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem47 = tableWidget_4->verticalHeaderItem(2);
        ___qtablewidgetitem47->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        QTableWidgetItem *___qtablewidgetitem48 = tableWidget_4->verticalHeaderItem(3);
        ___qtablewidgetitem48->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        QTableWidgetItem *___qtablewidgetitem49 = tableWidget_4->verticalHeaderItem(4);
        ___qtablewidgetitem49->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
        edit_4->setText(QCoreApplication::translate("MainWindow", "Search for Transaction", nullptr));
        edit_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        edit_7->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type here.....", nullptr));
        label_49->setText(QString());
        pushButton_31->setText(QCoreApplication::translate("MainWindow", "Delete Transaction", nullptr));
        pushButton_33->setText(QCoreApplication::translate("MainWindow", "Exporting PDF", nullptr));
        pic1_4->setText(QString());
        p9->setText(QCoreApplication::translate("MainWindow", "home    ", nullptr));
        p14->setText(QCoreApplication::translate("MainWindow", "HR manager", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "Add Employee", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "Statistic", nullptr));
        p11->setText(QCoreApplication::translate("MainWindow", "Transaction management", nullptr));
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "Add transaction", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "Statistic", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Prescription Manager", nullptr));
        pushButton_35->setText(QCoreApplication::translate("MainWindow", "Add Prescription", nullptr));
        pushButton_36->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        pushButton_37->setText(QCoreApplication::translate("MainWindow", "Statistic", nullptr));
        p13->setText(QCoreApplication::translate("MainWindow", "order management", nullptr));
        pushButton_25->setText(QCoreApplication::translate("MainWindow", "Add Order", nullptr));
        pushButton_24->setText(QCoreApplication::translate("MainWindow", "Statistic", nullptr));
        p10->setText(QCoreApplication::translate("MainWindow", "Stock management", nullptr));
        pushButton_27->setText(QCoreApplication::translate("MainWindow", "Add Cure", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "Statistic", nullptr));
        p15->setText(QCoreApplication::translate("MainWindow", " Settings", nullptr));
        p16->setText(QCoreApplication::translate("MainWindow", "Log out", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
